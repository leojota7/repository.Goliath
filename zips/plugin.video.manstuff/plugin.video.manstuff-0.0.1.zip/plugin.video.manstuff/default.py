#V 0.0.1
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , requests , urllib , urllib2 , json , os , re , sys , datetime , urlresolver , random , liveresolver , base64
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
import requests
import downloader as Get_Files
import extract
import time
if 64 - 64: i11iIiiIii
VVeve = 'plugin.video.manstuff'
VeevVee = Addon ( VVeve , sys . argv )
VevVevVVevVevVev = xbmcaddon . Addon ( id = VVeve )
iiiii = xbmcaddon . Addon ( ) . getAddonInfo
eeeevVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
Veveveeeeeevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'icon.png' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources/art' , 'next.png' ) )
IIi1IiiiI1Ii = base64 . b64decode ( 'aHR0cHM6Ly94aGFtc3Rlci5jb20v' )
I11i11Ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
eVeveveVe = requests . session ( )
VVVeev = xbmc . translatePath ( 'special://home/userdata/addon_data/' + VVeve )
Veeeeveveve = 'MAN STUFF'
IiIi11iIIi1Ii = xbmcgui . Dialog ( )
VeevV = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'repository.Goliath' ) )
if 44 - 44: iiiiIi11i . eevV / VeVV + I1iII1iiII
if 28 - 28: Ii11111i * iiI1i1
if 46 - 46: VeeevVVeveVV * Ii * Veeve
if not os . path . exists ( VeevV ) :
 VVVeveeve = xbmcgui . Dialog ( ) . yesno ( Veeeeveveve , 'This Add-on requires [COLOR cyan]Goliaths Repo[/COLOR] to be installed to work correctly would you like to install it now?' , '' , yeslabel = '[B][COLOR white]YES[/COLOR][/B]' , nolabel = '[B][COLOR grey]NO[/COLOR][/B]' )
 if VVVeveeve == 1 :
  Ii1iI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  if not os . path . exists ( Ii1iI ) :
   os . makedirs ( Ii1iI )
  Ve = base64 . b64decode ( b'aHR0cDovL21hdHNidWlsZHMudWsvcmVwby9yZXBvc2l0b3J5LkdvbGlhdGgtMi4wLjAuemlw' )
  I1Ii11I1Ii1i = xbmcgui . DialogProgress ( )
  I1Ii11I1Ii1i . create ( Veeeeveveve , "" , "" , "Downloading [COLOR cyan]Goliaths Repo[/COLOR]" )
  Vee = os . path . join ( Ii1iI , 'repo.zip' )
  if 56 - 56: eeVeveveVee - VevVVe
  try :
   os . remove ( Vee )
  except :
   pass
   if 8 - 8: Veeeevevevev * i1IIi11111i / I11i1i11i1I % ee / VVVevV / eeeveeVeveVVVVe
  Get_Files . download ( Ve , Vee , I1Ii11I1Ii1i )
  eVevevevVeVeeeveve = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  I1Ii11I1Ii1i . update ( 0 , "" , "Installing [COLOR red]Golitaths Repo[/COLOR] Please Wait" , "" )
  extract . all ( Vee , eVevevevVeVeeeveve , I1Ii11I1Ii1i )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  xbmc . executebuiltin ( "UpdateLocalAddons" )
  if 31 - 31: i111IiI + iIIIiI11 . VeVV
  if 9 - 9: iiI1i1 - ee % I1iII1iiII % VeVV
  if 3 - 3: VVVevV + iiiiIi11i
def I1Ii ( ) :
 eeveVeevVeeevV ( '[B][COLOR gold]Categories[/COLOR][/B]' , IIi1IiiiI1Ii + 'categories' , 39 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 eeveVeevVeeevV ( '[B][COLOR gold]Categories A-Z[/COLOR][/B]' , IIi1IiiiI1Ii + 'categories' , 38 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 eeveVeevVeeevV ( '[B][COLOR gold]Best[/COLOR][/B]' , IIi1IiiiI1Ii + 'best/weekly' , 37 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 eeveVeevVeeevV ( '[B][COLOR gold]Top Rated[/COLOR][/B]' , IIi1IiiiI1Ii + 'best/weekly' , 37 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 eeveVeevVeeevV ( '[B][COLOR gold]Top Viewed[/COLOR][/B]' , IIi1IiiiI1Ii + 'most-viewed' , 37 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 eeveVeevVeeevV ( '[B][COLOR gold]HD[/COLOR][/B]' , IIi1IiiiI1Ii + 'categories/hd-videos' , 37 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 eeveVeevVeeevV ( '[B][COLOR gold]Most Commented[/COLOR][/B]' , IIi1IiiiI1Ii + 'most-commented/weekly' , 37 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 eeveVeevVeeevV ( '[B][COLOR gold]Best of 2016[/COLOR][/B]' , IIi1IiiiI1Ii + 'videos/top/year/2016' , 37 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 eeveVeevVeeevV ( '[B][COLOR gold]Search[/COLOR][/B]' , 'url' , 40 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 81 - 81: VevVVe * eeeveeVeveVVVVe * I11i1i11i1I - VVVevV - eeVeveveVee
def VeeVevVV ( url ) :
 if 28 - 28: Ii11111i
 if 'xhamster.com' in url :
  url = url . replace ( 'https://xhamster.com' , '' )
 else :
  url = url
  if 28 - 28: eevV - I1iII1iiII
 VV = eVevV ( IIi1IiiiI1Ii + url )
 if 70 - 70: VeeevVVeveVV % VeeevVVeveVV . eeeveeVeveVVVVe % Ii * eeVeveveVee % Veeeevevevev
 if 23 - 23: i11iIiiIii + iiI1i1
 eVe = '<a class="video-thumb__image-container thumb-image-container" href="https:\/\/xhamster\.com(.*?)" data-sprite="(.*?)" data-previewvideo="(.*?)">'
 if 63 - 63: VeeevVVeveVV
 eeVeVeeevV = re . findall ( eVe , VV , re . DOTALL )
 if 76 - 76: iiiiIi11i / eeVeveveVee . iiI1i1 * ee - i1IIi11111i
 for Veee in eeVeVeeevV :
  Veveve = Veee [ 0 ] . replace ( '-' , ' ' ) . replace ( '/videos/' , '' )
  url = Veee [ 0 ]
  Veveveeeeeevev = Veee [ 1 ] . replace ( 's_' , '2_' )
  Vevev ( '[B][COLOR gold]' + Veveve + '[/COLOR][/B]' , url , 41 , Veveveeeeeevev , eeeevVV , '' )
  if 11 - 11: iiI1i1
 VeveevVe = re . compile ( '<link rel="next" href="(.+?)"' , re . DOTALL ) . findall ( VV )
 if 78 - 78: eevV - ee * Ii + eeVeveveVee + VVVevV + VVVevV
 for url in VeveevVe :
  Vevev ( '[B][COLOR white]Next Page>>>[/COLOR][/B]' , url , 37 , 'http://i.imgur.com/Uqrznbf.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 11 - 11: VVVevV - Ii % iIIIiI11 % VVVevV / Veeve - Ii
def eeveeveVVVeevee ( url ) :
 if 80 - 80: I11i1i11i1I * i11iIiiIii / i111IiI
 VV = eVevV ( url )
 if 9 - 9: ee + Veeeevevevev % ee + I1iII1iiII . i1IIi11111i
 III1i1i = re . findall ( '<div class="item">\s+<a href="https://xhamster.com/tags/(.*?)" >(.*?)</a>\s+</div>' , VV , re . DOTALL )
 if 26 - 26: VeVV
 for IiiI11Iiiii in III1i1i :
  if 18 - 18: eeVeveveVee
  I1i1I1II = IiiI11Iiiii [ 1 ]
  i1 = '/tags/' + IiiI11Iiiii [ 0 ]
  Vevev ( '[B][COLOR gold]' + I1i1I1II + '[/COLOR][/B]' , i1 , 37 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
  if 48 - 48: iiiiIi11i + iiiiIi11i - VevVVe . iIIIiI11 / eevV
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 77 - 77: I1iII1iiII % Veeve - eeeveeVeveVVVVe + iIIIiI11
def I11iiIiii ( url ) :
 if 1 - 1: Ii11111i - I11i1i11i1I / I11i1i11i1I
 VV = eVevV ( url )
 if 46 - 46: ee * i1IIi11111i - Ii * Veeeevevevev - i111IiI
 III1i1i = re . findall ( '<a href="https://xhamster.com/categories-(.*?)" class="view-all">' , VV , re . DOTALL )
 if 83 - 83: VeVV
 for IiiI11Iiiii in III1i1i :
  if 31 - 31: Ii11111i - i1IIi11111i . i111IiI % Veeve - iiiiIi11i
  I1i1I1II = IiiI11Iiiii [ 0 ]
  i1 = IIi1IiiiI1Ii + '/categories-' + IiiI11Iiiii [ 0 ]
  Vevev ( '[B][COLOR gold]' + I1i1I1II + '[/COLOR][/B]' , i1 , 39 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
  if 4 - 4: Ii11111i / iIIIiI11 . VVVevV
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 58 - 58: i1IIi11111i * i11iIiiIii / Veeve % i111IiI - VevVVe / Veeeevevevev
def ii11i1 ( url ) :
 VV = eVevV ( url )
 eVe = re . compile ( '<div class="letter-categories">(.+?)</ul>' , re . DOTALL ) . findall ( VV )
 IIIii1II1II = re . compile ( 'href="(.+?)"><span >(.+?)<' , re . DOTALL ) . findall ( str ( eVe ) )
 for url , Veveve in IIIii1II1II :
  Vevev ( '[B][COLOR gold]%s[/COLOR][/B]' % Veveve , url , 37 , 'https://i.imgur.com/kHN7aDk.jpg' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 42 - 42: ee + Veeeevevevev
def eevVeveevVe ( ) :
 Ii11Ii1I = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 Ii11Ii1I . doModal ( )
 if ( Ii11Ii1I . isConfirmed ( ) ) :
  VeveveV = Ii11Ii1I . getText ( ) . replace ( ' ' , '+' )
  Ve = IIi1IiiiI1Ii + 'search.php?from=&q=' + VeveveV + '&qcat=video'
  VeeVevVV ( Ve )
  if 39 - 39: eeeveeVeveVVVVe - Ii11111i * Ii % eeVeveveVee * Ii11111i % Ii11111i
def eVevV ( url ) :
 VeVVVVV = { }
 VeVVVVV [ 'User-Agent' ] = I11i11Ii
 iIi1i111II = eVeveveVe . get ( url , headers = VeVVVVV ) . text
 iIi1i111II = iIi1i111II . encode ( 'ascii' , 'ignore' )
 return iIi1i111II
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 83 - 83: i11iIiiIii + VevVVe - eeeveeVeveVVVVe * eeVeveveVee + I11i1i11i1I + Ii
def eevVevVevev ( url ) :
 IiIi11iIIi1Ii = xbmcgui . Dialog ( )
 if not 'https' in url :
  url = 'https://xhamster.com' + url
 eeveveve = [ ]
 I11IiI1I11i1i = [ ]
 if 38 - 38: eeVeveveVee
 VeevVIIi = ''
 if 26 - 26: VVVevV
 VV = eVevV ( url )
 if 91 - 91: Ii . VevVVe + Ii - VVVevV / VeVV
 iII1 = re . findall ( '"(\d+)p":"(.*?)"' , VV , re . DOTALL )
 if 30 - 30: Ii11111i - i1IIi11111i - i11iIiiIii % Veeve - Ii11111i * ee
 for eVevevVevVevV in iII1 :
  if 31 - 31: I11i1i11i1I - Ii11111i . I11i1i11i1I
  iIi1i111II = eVevevVevVevV [ 1 ] . replace ( '\\' , '' )
  if 18 - 18: eeVeveveVee
  if '.flv' in eVevevVevVevV [ 1 ] :
   VeevVIIi = '[B][COLOR gold]FLV : ' + eVevevVevVevV [ 0 ] + '[/COLOR][/B]'
  elif '.mp4' in eVevevVevVevV [ 1 ] :
   VeevVIIi = '[B][COLOR gold]MP4 : ' + eVevevVevVevV [ 0 ] + '[/COLOR][/B]'
   if 98 - 98: VVVevV * VVVevV / VVVevV + I11i1i11i1I
  eeveveve . append ( VeevVIIi )
  I11IiI1I11i1i . append ( iIi1i111II )
  if 34 - 34: iIIIiI11
 if len ( eeveveve ) > 1 :
  IiIi11iIIi1Ii = xbmcgui . Dialog ( )
  I1111I1iII11 = IiIi11iIIi1Ii . select ( 'Please Select Quality' , eeveveve )
  if 59 - 59: eevV * i11iIiiIii / VevVVe * I1iII1iiII * iiiiIi11i
  if I1111I1iII11 == - 1 :
   return
  elif I1111I1iII11 > - 1 :
   url = I11IiI1I11i1i [ I1111I1iII11 ]
   if 83 - 83: Ii / i111IiI . Veeve / eeeveeVeveVVVVe . Veeve . i1IIi11111i
 VeveVeVV = xbmcgui . ListItem ( Veveve , iconImage = 'DefaultVideo.png' , thumbnailImage = eVeveveev )
 VeveVeVV . setInfo ( type = 'Video' , infoLabels = { "Title" : Veveve } )
 VeveVeVV . setProperty ( "IsPlayable" , "true" )
 VeveVeVV . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , VeveVeVV )
 if 55 - 55: VeeevVVeveVV + eevV / Veeve * Veeeevevevev - i11iIiiIii - ee
def Vevev ( name , url , mode , iconimage , fanart , description ) :
 ii1ii1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 eeeeeVeeeveee = True
 VeveVeVV = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 VeveVeVV . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 VeveVeVV . setProperty ( 'fanart_image' , fanart )
 if mode == 41 :
  VeveVeVV . setProperty ( "IsPlayable" , "true" )
  eeeeeVeeeveee = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1ii1ii , listitem = VeveVeVV , isFolder = False )
 else :
  eeeeeVeeeveee = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1ii1ii , listitem = VeveVeVV , isFolder = True )
 return eeeeeVeeeveee
 if 6 - 6: I11i1i11i1I - ee + eevV - i111IiI - i11iIiiIii
 if 79 - 79: Veeve - iiiiIi11i * Ii + Veeve % iiiiIi11i * iiiiIi11i
def eVVeev ( ) :
 eeevevVeveveV = [ ]
 iIiIIIi = sys . argv [ 2 ]
 if len ( iIiIIIi ) >= 2 :
  eeeevevVVVeeV = sys . argv [ 2 ]
  VevevVVVeVeeevV = eeeevevVVVeeV . replace ( '?' , '' )
  if ( eeeevevVVVeeV [ len ( eeeevevVVVeeV ) - 1 ] == '/' ) :
   eeeevevVVVeeV = eeeevevVVVeeV [ 0 : len ( eeeevevVVVeeV ) - 2 ]
  VevevevVVeevevee = VevevVVVeVeeevV . split ( '&' )
  eeevevVeveveV = { }
  for eeevVVe in range ( len ( VevevevVVeevevee ) ) :
   eeVVVevevVee = { }
   eeVVVevevVee = VevevevVVeevevee [ eeevVVe ] . split ( '=' )
   if ( len ( eeVVVevevVee ) ) == 2 :
    eeevevVeveveV [ eeVVVevevVee [ 0 ] ] = eeVVVevevVee [ 1 ]
 return eeevevVeveveV
 if 16 - 16: Ii11111i % Veeve - Ii11111i + ee
 if 12 - 12: i1IIi11111i / i1IIi11111i + i11iIiiIii
def eeveVeevVeeevV ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 ii1ii1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 eeeeeVeeeveee = True
 VeveVeVV = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 VeveVeVV . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 VeveVeVV . setProperty ( 'fanart_image' , fanart )
 if 'youtube.com/channel/' in url :
  ii1ii1ii = 'plugin://plugin.video.youtube/channel/' + description + '/'
 if 'youtube.com/user/' in url :
  ii1ii1ii = 'plugin://plugin.video.youtube/user/' + description + '/'
 if 'youtube.com/playlist?' in url :
  ii1ii1ii = 'plugin://plugin.video.youtube/playlist/' + description + '/'
 if 'plugin://' in url :
  ii1ii1ii = url
 Iiiii1i = [ ]
 I11i1ii1 = VevVevVVevVevVev . getSetting ( 'favlist' )
 if I11i1ii1 == 'yes' : Iiiii1i . append ( ( '[COLOR cyan]Remove From Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : Iiiii1i . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 VeveVeVV . addContextMenuItems ( Iiiii1i , replaceItems = False )
 eeeeeVeeeveee = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1ii1ii , listitem = VeveVeVV , isFolder = True )
 return eeeeeVeeeveee
 if 87 - 87: I11i1i11i1I - eevV + iiI1i1 . VVVevV
eeeevevVVVeeV = eVVeev ( ) ; Ve = None ; Veveve = None ; VeeveVVVeVeeVe = None ; Vevevevee = None ; eVeveveev = None ; IIi1I11I1II = None
try : Vevevevee = urllib . unquote_plus ( eeeevevVVVeeV [ "site" ] )
except : pass
try : Ve = urllib . unquote_plus ( eeeevevVVVeeV [ "url" ] )
except : pass
try : Veveve = urllib . unquote_plus ( eeeevevVVVeeV [ "name" ] )
except : pass
try : VeeveVVVeVeeVe = int ( eeeevevVVVeeV [ "mode" ] )
except : pass
try : eVeveveev = urllib . unquote_plus ( eeeevevVVVeeV [ "iconimage" ] )
except : pass
try : eeeevVV = urllib . unquote_plus ( eeeevevVVVeeV [ "fanart" ] )
except : pass
try : IIi1I11I1II = str ( eeeevevVVVeeV [ "description" ] )
except : pass
if 63 - 63: VeVV - Ii . Ii11111i / eeVeveveVee . Veeve / iiiiIi11i
if VeeveVVVeVeeVe == None or Ve == None or len ( Ve ) < 1 : I1Ii ( )
elif VeeveVVVeVeeVe == 37 : VeeVevVV ( Ve )
elif VeeveVVVeVeeVe == 38 : I11iiIiii ( Ve )
elif VeeveVVVeVeeVe == 39 : eeveeveVVVeevee ( Ve )
elif VeeveVVVeVeeVe == 40 : eevVeveevVe ( )
elif VeeveVVVeVeeVe == 41 : eevVevVevev ( Ve )
elif VeeveVVVeVeeVe == 42 : ii11i1 ( Ve )
if 84 - 84: eeeveeVeveVVVVe
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
