#V 1.0.10
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , requests , urllib , urllib2 , json , os , re , sys , datetime , urlresolver , random , liveresolver , base64 , pyxbmct
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
import nanscrapers
import requests
import downloader as Get_Files
import extract
import time
if 64 - 64: i11iIiiIii
VVeve = 'plugin.video.picasso'
VeevVee = Addon ( VVeve , sys . argv )
VevVevVVevVevVev = xbmcaddon . Addon ( id = VVeve )
iiiii = xbmcaddon . Addon ( ) . getAddonInfo
eeeevVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
Veveveeeeeevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'icon.png' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources/art' , 'next.png' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources' , 'rd.txt' ) )
I11i11Ii = 'http://matsbuilds.uk/pin'
eVeveveVe = xbmcaddon . Addon ( ) . getSetting ( 'password' )
VVVeev = xbmcaddon . Addon ( ) . getSetting ( 'enable_meta' )
Veeeeveveve = base64 . b64decode ( 'aHR0cHM6Ly94aGFtc3Rlci5jb20v' )
IiIi11iIIi1Ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
VeevV = requests . session ( )
IiI = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvaW5mby50eHQ=' )
eeVe = xbmc . translatePath ( 'special://home/userdata/addon_data/' + VVeve )
Ve = xbmc . translatePath ( os . path . join ( 'special://home/userdata/Database' , 'picasso.db' ) )
eevV = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'repository.Goliath' ) )
IiiIII111iI = '[COLOR cyan]Picasso[/COLOR]'
IiII = open ( Ve , 'a' )
IiII . close ( )
if 28 - 28: Ii11111i * iiI1i1
if 46 - 46: VeeevVVeveVV * Ii * Veeve
if not os . path . exists ( eevV ) :
 VVVeveeve = xbmcgui . Dialog ( ) . yesno ( IiiIII111iI , 'This Add-on requires [COLOR cyan]Goliaths Repo[/COLOR] to be installed to work correctly would you like to install it now?' , '' , yeslabel = '[B][COLOR white]YES[/COLOR][/B]' , nolabel = '[B][COLOR grey]NO[/COLOR][/B]' )
 if VVVeveeve == 1 :
  Ii1iI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  if not os . path . exists ( Ii1iI ) :
   os . makedirs ( Ii1iI )
  VeI1Ii11I1Ii1i = base64 . b64decode ( b'aHR0cDovL21hdHNidWlsZHMudWsvZ29saWF0aC9yZXBvc2l0b3J5LkdvbGlhdGgtMS40LnppcA==' )
  Vee = xbmcgui . DialogProgress ( )
  Vee . create ( IiiIII111iI , "" , "" , "Downloading [COLOR cyan]Goliaths Repo[/COLOR]" )
  eeveVeVeveve = os . path . join ( Ii1iI , 'repo.zip' )
  if 43 - 43: VevVVe . II1Iiii1111i
  try :
   os . remove ( eeveVeVeveve )
  except :
   pass
   if 25 - 25: VVeevevev
  Get_Files . download ( VeI1Ii11I1Ii1i , eeveVeVeveve , Vee )
  Vev = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  Vee . update ( 0 , "" , "Installing [COLOR red]Golitaths Repo[/COLOR] Please Wait" , "" )
  extract . all ( eeveVeVeveve , Vev , Vee )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  xbmc . executebuiltin ( "UpdateLocalAddons" )
  if 34 - 34: Veveevev % eeveee / VVVevV / I1ii * eVVVeeveevV + VVeVeeevevee
  if 41 - 41: i11IiIiiIIIII / IiiIII111ii / i1iIIi1
def ii11iIi1I ( st ) :
 import re
 st = re . sub ( '\[.+\]' , '' , st )
 import string
 iI111I11I1I1 = 0
 for VeevV in st :
  if VeevV in 'lij|\' ' : iI111I11I1I1 += 37
  elif VeevV in '![]fI.,:;/\\t' : iI111I11I1I1 += 50
  elif VeevV in '`-(){}r"' : iI111I11I1I1 += 60
  elif VeevV in '*^zcsJkvxy' : iI111I11I1I1 += 85
  elif VeevV in 'aebdhnopqug#$L+<>=?_~FZT' + string . digits : iI111I11I1I1 += 95
  elif VeevV in 'BSPEAKVXY&UwNRCHD' : iI111I11I1I1 += 112
  elif VeevV in 'QGOMm%W@' : iI111I11I1I1 += 135
  else : iI111I11I1I1 += 50
 return int ( iI111I11I1I1 * 6.5 / 100 )
 if 55 - 55: iI1I % iiiIi - eVVVeeveevV / Ii11111i % eeveee + VVeevevev
def iI111IiI111I ( Heading = xbmcaddon . Addon ( ) . getAddonInfo ( 'name' ) ) :
 VeeVeVevVe = xbmc . Keyboard ( '' , Heading )
 VeeVeVevVe . doModal ( )
 if ( VeeVeVevVe . isConfirmed ( ) ) :
  return VeeVeVevVe . getText ( )
  if 47 - 47: I1ii
def iiIiIiIi ( url ) :
 if 33 - 33: i11IiIiiIIIII + Veeve % i11iIiiIii . iiiIi - VevVVe
 import webbrowser
 if 66 - 66: i11IiIiiIIIII - VeeevVVeveVV * VeeevVVeveVV . eVVVeeveevV . VVVevV
 IiI1i11iii1 = webbrowser . open
 eeevVeevevVeev = xbmc . executebuiltin
 eVVVeveve = lambda VevVeveveevVVVev : xbmc . getCondVisibility ( str ( VevVeveveevVVVev ) )
 Ii1iIIIi1ii = lambda VevVeveveevVVVev : eeevVeevevVeev ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( VevVeveveevVVVev ) )
 if 80 - 80: VVeVeeevevee * i11iIiiIii / iI1I
 I11II1i = 'System.Platform.Android'
 if 23 - 23: VVVevV / eeveee + VVeVeeevevee + VVeVeeevevee / Veeve
 if eVVVeveve ( I11II1i ) : Ii1iIIIi1ii ( base64 . b64decode ( url ) )
 else : IiI1i11iii1 ( base64 . b64decode ( url ) )
 if 26 - 26: VeeevVVeveVV
 if 12 - 12: VeeevVVeveVV % Veveevev / iiiIi % eeveee
def iiii ( ) :
 if 54 - 54: VVVevV * eVVVeeveevV
 if 13 - 13: i1iIIi1 + Veveevev - VeeevVVeveVV + iI1I . IiiIII111ii + VVeevevev
 import sys
 if 8 - 8: iiI1i1 . VevVVe - iiI1i1 * i11IiIiiIIIII
 VVVV = 'aHR0cDovL29mZnNob3JlcGx1Z2lucy5jb20vcG9ydGFsL2FwcHMucGhw'
 VVVevev = 'YzFkZmYwYzYxZjQ3MDY0'
 iiiiiIIii = base64 . b64decode ( 'aHR0cDovL29mZnNob3JlcGx1Z2lucy5jb20vcG9ydGFsL2FwaS5waHA/cGluPSVzJmtleT0=' ) + base64 . b64decode ( VVVevev )
 VevevevVVev = 'W0NPTE9SIGN5YW5dSW4gb3JkZXIgdG8gY29udGludWUgcGxlYXNlWy9DT0xPUl0gW0NPTE9SIHdoaXRlXVtCXVZFUklGWVsvQl1bL0NPTE9SXSBbQ09MT1IgY3lhbl15b3VyIGRldmljZSBieSBnZXR0aW5nIGFbL0NPTE9SXVtDT0xPUiB3aGl0ZV1bQl0gRlJFRSBQSU5bL0JdWy9DT0xPUl1bQ09MT1IgY3lhbl0gZnJvbSBvdXIgd2Vic2l0ZSBhbmQgZW50ZXJpbmcgdGhlIHBpbiBvbiB0aGUgbmV4dCBwcm9tdC4gIFsvQ09MT1JdW0NPTE9SIHdoaXRlXVtCXXwgICB3d3cubWF0c2J1aWxkcy51ay9waW5bL0JdWy9DT0xPUl0='
 if 43 - 43: iI1I - Ii11111i % VevVVe . VVeVeeevevee
 eevev = base64 . b64decode ( VevevevVVev )
 VeeVeee = xbmcaddon . Addon ( ) . getAddonInfo
 VeveveveeevV = xbmcaddon . Addon ( ) . getSetting ( 'pin' )
 VVVVi11i1 = lambda VevVeveveevVVVev : base64 . b64decode ( str ( VevVeveveevVVVev ) )
 IIIii1II1II = lambda VevVeveveevVVVev : requests . get ( iiiiiIIii % ( VevVeveveevVVVev ) ) . text . strip ( )
 i1I1iI = lambda VevVeveveevVVVev : xbmcaddon . Addon ( ) . setSetting ( base64 . b64decode ( 'cGlu' ) , VevVeveveevVVVev )
 eeevVeeVVeev = lambda VevVeveveevVVVev : xbmcgui . Dialog ( ) . yesno ( VeeVeee ( 'name' ) , VevVeveveevVVVev , yeslabel = "Get A Pin" , nolabel = 'Cancel' )
 eevVVeveveV = bool ( IIIii1II1II ( VeveveveeevV ) == base64 . b64decode ( 'UGluIFZlcmlmaWVk' ) )
 if 39 - 39: i1iIIi1 - Veeve * VVeevevev % eeveee * Veeve % Veeve
 if eevVVeveveV : return
 else :
  if 59 - 59: iiI1i1 + VevVVe - eeveee - VevVVe + eVVVeeveevV / VVVevV
  if eeevVeeVVeev ( eevev ) :
   iiIiIiIi ( VVVV )
   I1 = iI111IiI111I ( 'Type Your Pin Here' )
   i1I1iI ( I1 )
   iiii ( )
  else : sys . exit ( )
  if 71 - 71: eVVVeeveevV + iiiIi % i11iIiiIii + VVVevV - i1iIIi1
  if 88 - 88: Veveevev - VVeevevev % eVVVeeveevV
  if 16 - 16: VevVVe * I1ii % i1iIIi1
def Veeveveve ( ) :
 if not os . path . exists ( eeVe ) :
  os . mkdir ( eeVe )
 I11IiI1I11i1i ( IiI , 'GlobalCompare' )
 iI1ii1Ii ( '[B][COLOR yellow]Keep Safe[/COLOR][/B]' , 'url' , 22 , 'http://i.imgur.com/cR0cP8f.png' , II1 )
 iI1ii1Ii ( '[B][COLOR yellow]Find It...[/COLOR][/B]' , 'url' , 5 , 'http://i.imgur.com/ZQYQyHG.png' , II1 )
 iI1ii1Ii ( '[B][COLOR cyan]Movie Madness[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL01haW5tZW51LnhtbA==' ) , 26 , 'http://i.imgur.com/Y2rejnc.png' , II1 )
 iI1ii1Ii ( '[B][COLOR cyan]Telly Box[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvVHZTaG93cy9NYWlubWVudS54bWw=' ) , 27 , 'http://i.imgur.com/63LrHYW.png' , II1 )
 eeeeevevev = iIIIi1 ( iiII1i1 )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV in VVeVVeveeeveeV :
   iI1ii1Ii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , 1 , VevevVeveVVevevVevev , eeeevVV )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 11 - 11: i1iIIi1 . VVVevV
def eev ( name , url , iconimage , fanart ) :
 iI1ii1Ii ( '[B][COLOR yellow]MOVIE SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL1NlYXJjaC9TZWFyY2gudHh0' ) , 5 , 'http://i.imgur.com/QArRVYb.png' , II1 )
 iI1ii1Ii ( '[B][COLOR yellow]UK CINEMA RELEASE DATES[/COLOR][/B]' , 'http://www.empireonline.com/movies/features/upcoming-movies/' , 34 , 'http://i.imgur.com/aKQgDR7.png' , II1 )
 eeeeevevev = iIIIi1 ( url )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for name , url , iconimage , fanart in VVeVVeveeeveeV :
   eeeveVe ( name , url , iconimage , fanart , VVVevevV )
   if 89 - 89: Veveevev
def VVeveVeVVeveVVev ( name , url , iconimage , fanarts ) :
 iI1ii1Ii ( '[B][COLOR yellow]TV SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvYW5ld0V2b2x2ZW1lbnUvc2VhcmNoLnhtbA==' ) , 33 , 'http://i.imgur.com/he5RFkL.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]TV SCHEDULE[/COLOR][/B]' , 'http://www.tvwise.co.uk/uk-premiere-dates/' , 32 , 'http://i.imgur.com/XKAapZH.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]Latest Episodes[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20=' ) , 28 , 'http://i.imgur.com/n8itltl.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]Popular Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9wb3B1bGFyLXNlcmllcw==' ) , 29 , 'http://i.imgur.com/ury75ui.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]New Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9uZXctc2VyaWVz' ) , 30 , 'http://i.imgur.com/UPWjTLw.png' , fanarts )
 if 86 - 86: eVVVeeveevV
 VVeeevV = VeeveeVeeve ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , VVeeevV )
 eeeeevevev = iIIIi1 ( url )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for name , url , iconimage , eeeevVV in VVeVVeveeeveeV :
   eeeveVe ( name , url , iconimage , eeeevVV , VVVevevV )
   if 22 - 22: iiI1i1 / i11iIiiIii * iiI1i1 * Veeve . eVVVeeveevV / i11iIiiIii
def Iiii ( name , url , iconimage , fanart ) :
 VVeeevV = VeeveeVeeve ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , VVeeevV )
 eeeeevevev = iIIIi1 ( url )
 VVevVeVeveevev ( eeeeevevev )
 if '<message>' in eeeeevevev :
  IiI = re . compile ( '<message>(.+?)</message>' ) . findall ( eeeeevevev ) [ 0 ]
  I11IiI1I11i1i ( IiI , VVeeevV )
 if '<intro>' in eeeeevevev :
  eeVVevVeveeVeeV = re . compile ( '<intro>(.+?)</intro>' ) . findall ( eeeeevevev ) [ 0 ]
  eVVVeevevVeveveVe ( eeVVevVeveeVeeV )
 if 'XXX>yes</XXX' in eeeeevevev : iiIIIi ( eeeeevevev )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  eeeveVe ( name , url , iconimage , fanart , VVVevevV )
  if 93 - 93: IiiIII111ii
def eeeveVe ( name , url , iconimage , fanart , item ) :
 try :
  if '<sportsdevil>' in item : i1IIIiiII1 ( name , url , iconimage , fanart , item )
  elif '<iplayer>' in item : VVVVeVeeevVevVev ( name , url , iconimage , fanart , item )
  elif '<folder>' in item : VVVeeveveeeveV ( name , url , iconimage , fanart , item )
  elif '<iptv>' in item : IIiIi1iI ( name , url , iconimage , fanart , item )
  elif '<image>' in item : i1IiiiI1iI ( name , url , iconimage , fanart , item )
  elif '<text>' in item : i1iIi ( name , url , iconimage , fanart , item )
  elif '<scraper>' in item : eeVVeeeeee ( name , url , iconimage , fanart , item )
  elif '<lbscraper>' in item : II1I ( name , url , iconimage , fanart , item )
  elif '<redirect>' in item : Vevi1II1Iiii1I11 ( name , url , iconimage , fanart , item )
  elif '<oktitle>' in item : IIII ( name , url , iconimage , fanart , item )
  elif '<nan>' in item : iiIiI ( name , url , iconimage , fanart , item )
  elif '<adult>' in item : eeveveeeVevVe ( name , url , iconimage , fanart , item )
  else : eevVevVVVevVee ( name , url , iconimage , fanart , item )
 except : pass
 if 45 - 45: Ii11111i / eeveee
def VVVVeVeeevVevVev ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<iplayer>(.+?)</iplayer>' ) . findall ( item ) [ 0 ]
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 url = 'plugin://plugin.video.iplayerwww/?url=%s&mode=202&name=%s&iconimage=%s&description=&subtitles_url=&logged_in=False' % ( url , name , iconimage )
 i1 ( name , url , 16 , iconimage , fanart )
 if 8 - 8: I1ii * Veveevev - i11IiIiiIIIII - VVeevevev * eVVVeeveevV % VevVVe
def iiIiI ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 ii = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 eVeeVVVeVe = re . compile ( '<nan>(.+?)</nan>' ) . findall ( item ) [ 0 ]
 i1Iii1i1I = re . compile ( '<imdb>(.+?)</imdb>' ) . findall ( item ) [ 0 ]
 if eVeeVVVeVe == 'movie' :
  i1Iii1i1I = i1Iii1i1I + '<>movie'
 elif eVeeVVVeVe == 'tvshow' :
  VVeVevev = re . compile ( '<showname>(.+?)</showname>' ) . findall ( item ) [ 0 ]
  IiI111111IIII = re . compile ( '<season>(.+?)</season>' ) . findall ( item ) [ 0 ]
  i1Ii = re . compile ( '<episode>(.+?)</episode>' ) . findall ( item ) [ 0 ]
  ii111iI1iIi1 = re . compile ( '<showyear>(.+?)</showyear>' ) . findall ( item ) [ 0 ]
  VVV = re . compile ( '<episodeyear>(.+?)</episodeyear>' ) . findall ( item ) [ 0 ]
  i1Iii1i1I = i1Iii1i1I + '<>' + VVeVevev + '<>' + IiI111111IIII + '<>' + i1Ii + '<>' + ii111iI1iIi1 + '<>' + VVV
  eVeeVVVeVe = "tvep"
 eeevVVeev ( name , i1Iii1i1I , 19 , iconimage , 1 , eVeeVVVeVe , isFolder = True )
 if 47 - 47: iI1I + Veveevev * II1Iiii1111i / iiiIi - IiiIII111ii % iiI1i1
def IIi11i1i1iI1 ( name , imdb , iconimage , fanart ) :
 IIi1IiiiI1Ii = ''
 iiiIi1 = name
 VVeeevV = VeeveeVeeve ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , VVeeevV )
 if 'movie' in imdb :
  imdb = imdb . split ( '<>' ) [ 0 ]
  i1I1ii11i1Iii = [ ]
  I1IiiiiI = [ ]
  eevVIiII = name . partition ( '(' )
  ii1iII1II = eevVIiII [ 0 ]
  ii1iII1II = VeeveeVeeve ( ii1iII1II )
  Iii1I1I11iiI1 = eevVIiII [ 2 ] . partition ( ')' ) [ 0 ]
  I1I1i1I = nanscrapers . scrape_movie ( ii1iII1II , Iii1I1I11iiI1 , imdb , timeout = 800 )
 else :
  VVeVevev = imdb . split ( '<>' ) [ 1 ]
  ii1I = imdb . split ( '<>' ) [ 0 ]
  IiI111111IIII = imdb . split ( '<>' ) [ 2 ]
  i1Ii = imdb . split ( '<>' ) [ 3 ]
  ii111iI1iIi1 = imdb . split ( '<>' ) [ 4 ]
  VVV = imdb . split ( '<>' ) [ 5 ]
  I1I1i1I = nanscrapers . scrape_episode ( VVeVevev , ii111iI1iIi1 , VVV , IiI111111IIII , i1Ii , ii1I , None )
 VeveVev = 1
 for eVev in list ( I1I1i1I ( ) ) :
  for VevVVevV in eVev :
   if urlresolver . HostedMediaFile ( VevVVevV [ 'url' ] ) . valid_url ( ) :
    IIi1IiiiI1Ii = VV ( VevVVevV [ 'url' ] )
    name = "Link " + str ( VeveVev ) + ' | ' + VevVVevV [ 'source' ] + IIi1IiiiI1Ii
    VeveVev = VeveVev + 1
    VeVeV ( name , VevVVevV [ 'url' ] , 2 , iconimage , fanart , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
    if 43 - 43: i11iIiiIii + II1Iiii1111i * Veeve * iI1I * Ii11111i
    if 64 - 64: eVVVeeveevV % iiI1i1 * I1ii
def eeveveeeVevVe ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<adult>(.+?)</adult>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 36 , iconimage , fanart )
 if 79 - 79: Ii11111i
def eVVevevV ( ) :
 iI1ii1Ii ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Top Viewed[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-viewed.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]HD[/COLOR][/B]' , Veeeeveveve + 'categories/hd-videos' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Most Commented[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-commented.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]50 Newest[/COLOR][/B]' , Veeeeveveve + 'last50.php' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Best of 2016[/COLOR][/B]' , Veeeeveveve + 'videos/top/year/2016' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]All-time Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/alltime-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Main Categories[/COLOR][/B]' , Veeeeveveve , 39 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]All Categories Alpha[/COLOR][/B]' , Veeeeveveve + 'categories' , 38 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Search[/COLOR][/B]' , 'url' , 40 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 77 - 77: II1Iiii1111i - Ii - VVeVeeevevee . Veveevev
def IiI1i ( url ) :
 eevVeevev = iI ( url )
 VevVevVeeeeve = re . compile ( '<div class="video"><a href="(.+?)" class=".+?"><div class=".+?"  data-previewvideo=".+?"><img src=\'(.+?)\' class=\'.+?\' alt="(.+?)"/><img class=\'.+?\' src=\'.+?\'' , re . DOTALL ) . findall ( eevVeevev )
 for url , Veveveeeeeevev , VeveevVevevVeeveev in VevVevVeeeeve :
  VeveevVevevVeeveev = VeveevVevevVeeveev . replace ( '&#039;' , '\'' ) . replace ( '&amp;' , ' & ' )
  eVVeeevevVeveve ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 41 , Veveveeeeeevev , eeeevVV , '' )
 VevVevevVe = re . compile ( '<link rel="next" href="(.+?)"' , re . DOTALL ) . findall ( eevVeevev )
 for url in VevVevevVe :
  eVVeeevevVeveve ( '[B][COLOR cyan]Next Page>>>[/COLOR][/B]' , url , 37 , 'http://i.imgur.com/Uqrznbf.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 97 - 97: Ii11111i * VeeevVVeveVV . VeeevVVeveVV
def I111iI ( url ) :
 eevVeevev = iI ( url )
 VevVevVeeeeve = re . compile ( '<div class="list">(.+?)<div class="head"' , re . DOTALL ) . findall ( eevVeevev ) [ 1 ]
 eVVeev = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( str ( VevVevVeeeeve ) )
 for url in eVVeev :
  VeveevVevevVeeveev = url . split ( 'xhamster.com/' ) [ 1 ]
  try :
   VeveevVevevVeeveev = VeveevVevevVeeveev . replace ( '-1.html' , '' )
   VeveevVevevVeeveev = VeveevVevevVeeveev . split ( '/' ) [ 1 ] . title ( )
  except : pass
  if 'categories' not in VeveevVevevVeeveev :
   eVVeeevevVeveve ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 16 - 16: I1ii % VVVevV * i11iIiiIii % i11iIiiIii
def VevVVVVeevV ( url ) :
 eevVeevev = iI ( url )
 VevVevVeeeeve = re . compile ( 'ul class="alphabet-block".+?<a class=""(.+?)</ul>' , re . DOTALL ) . findall ( eevVeevev )
 eVVeev = re . compile ( 'href="(.+?)">(.+?)<' , re . DOTALL ) . findall ( str ( VevVevVeeeeve ) )
 for url , VeveevVevevVeeveev in eVVeev :
  eVVeeevevVeveve ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 42 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 81 - 81: Ii11111i / VVeevevev . Ii + VevVVe - VVeVeeevevee
def VeVVeVeeeeVVe ( url ) :
 eevVeevev = iI ( url )
 VevVevVeeeeve = re . compile ( '<div class="letter-categories">(.+?)</ul>' , re . DOTALL ) . findall ( eevVeevev )
 eVVeev = re . compile ( 'href="(.+?)"><span >(.+?)<' , re . DOTALL ) . findall ( str ( VevVevVeeeeve ) )
 for url , VeveevVevevVeeveev in eVVeev :
  eVVeeevevVeveve ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 87 - 87: VevVVe
def eVVVeeevVeveV ( ) :
 iIII1I111III = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 iIII1I111III . doModal ( )
 if ( iIII1I111III . isConfirmed ( ) ) :
  II = iIII1I111III . getText ( ) . replace ( ' ' , '+' )
  VeI1Ii11I1Ii1i = Veeeeveveve + 'search.php?from=&q=' + II + '&qcat=video'
  IiI1i ( VeI1Ii11I1Ii1i )
  if 77 - 77: eVVVeeveevV * iiI1i1
def iI ( url ) :
 eVeveveVVeeeV = { }
 eVeveveVVeeeV [ 'User-Agent' ] = IiIi11iIIi1Ii
 eeeeevevev = VeevV . get ( url , headers = eVeveveVVeeeV ) . text
 eeeeevevev = eeeeevevev . encode ( 'ascii' , 'ignore' )
 return eeeeevevev
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 46 - 46: VevVVe - VeeevVVeveVV - VVeVeeevevee * Veeve
def I1i1I11I ( url ) :
 VeVevevevVevVe = [ ]
 VeeveeveeeeevVev = [ ]
 VeeeeVVeeev = ''
 eevVeevev = iI ( url )
 eeveveVVeve = re . compile ( 'sources:(.+?)allowFullScreen:' , re . DOTALL ) . findall ( eevVeevev ) [ 0 ]
 i1I1IiiIi1i = re . compile ( '"(.+?)":"(.+?)"' , re . DOTALL ) . findall ( str ( eeveveVVeve ) )
 for iiI11ii1I1 , eeeeevevev in i1I1IiiIi1i :
  VeeeeVVeeev = '[B][COLOR cyan]%s[/COLOR][/B]' % iiI11ii1I1
  VeVevevevVevVe . append ( VeeeeVVeeev )
  VeeveeveeeeevVev . append ( eeeeevevev )
 if len ( eeveveVVeve ) > 1 :
  VeeevVVeVeVev = xbmcgui . Dialog ( )
  eVeevVVeVev = VeeevVVeVeVev . select ( 'Please Select Quality' , VeVevevevVevVe )
  if eVeevVVeVev == - 1 :
   return
  elif eVeevVVeVev > - 1 :
   url = VeeveeveeeeevVev [ eVeevVVeVev ]
 else :
  url = re . compile ( 'sources: {".+?":"(.+?)"' ) . findall ( eevVeevev ) [ 0 ]
 url = url . replace ( '\/' , '/' )
 IIeevVeeveVeveVVevev = xbmcgui . ListItem ( VeveevVevevVeeveev , iconImage = 'DefaultVideo.png' , thumbnailImage = VevevVeveVVevevVevev )
 IIeevVeeveVeveVVevev . setInfo ( type = 'Video' , infoLabels = { "Title" : VeveevVevevVeeveev } )
 IIeevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
 IIeevVeeveVeveVVevev . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IIeevVeeveVeveVVevev )
 if 92 - 92: VeeevVVeveVV * iI1I
def eVVeeevevVeveve ( name , url , mode , iconimage , fanart , description ) :
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 I1II1 = True
 IIeevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIeevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IIeevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 if mode == 41 :
  IIeevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
  I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = IIeevVeeveVeveVVevev , isFolder = False )
 else :
  I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = IIeevVeeveVeveVVevev , isFolder = True )
 return I1II1
 if 86 - 86: iiI1i1 / Veveevev . Veeve
 if 19 - 19: VVVevV % VeeevVVeveVV % i1iIIi1 * eeveee % Ii11111i
 if 67 - 67: VevVVe . Ii
def eeVVeeeeee ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<scraper>(.+?)</scraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 18 , iconimage , fanart )
 if 27 - 27: iiiIi % VevVVe
def eeveeeVVevev ( name , url , iconimage , fanart ) :
 iiIiii1IIIII = url
 if iiIiii1IIIII == 'latestmovies' :
  eeveve = 15
  IIIIiiIiiI = MOVIESINDEXER ( )
  IIIIiI11I11 = re . compile ( '<item>(.+?)</item>' ) . findall ( IIIIiiIiiI )
  for VVVevevV in IIIIiI11I11 :
   VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
   eeeveveev = len ( IIIIiI11I11 )
   for name , url , iconimage , fanart in VVeVVeveeeveeV :
    if '<meta>' in VVVevevV :
     i11II1I11I1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( VVVevevV ) [ 0 ]
     eeevVVeev ( name , url , eeveve , iconimage , eeeveveev , i11II1I11I1 , isFolder = False )
    else : VeVeV ( name , url , 15 , iconimage , fanart )
    if 67 - 67: VevVVe - eeveee / VVeVeeevevee - Ii
    if 1 - 1: Veeve
def VeveVeeveve ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( 'http://www.watchepisodes4.com' )
 iiIi11iI1iii = re . compile ( '<a title=".+?" .+? style="background-image: url(.+?)"></a>.+?<div class="hb-right">.+?<a title=".+?" href="(.+?)" class="episode">(.+?)</a>' , re . DOTALL ) . findall ( eeeeevevev )
 for iconimage , url , name in iiIi11iI1iii :
  iconimage = iconimage . replace ( "('" , "" ) . replace ( "')" , "" )
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  name = name . split ( '  ' ) [ 0 ]
  iI1ii1Ii ( name , url , 24 , iconimage , iconimage )
  if 67 - 67: Ii11111i / iI1I
def VVVeveveveveV ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( name , url , 31 , iconimage , iconimage )
  if 15 - 15: Veveevev % VevVVe * VVeVeeevevee
def VevVeeeVev ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( name , url , 31 , iconimage , iconimage )
  if 85 - 85: VVeVeeevevee
def iI1i11II1i ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 iIi1I11I = re . compile ( '<div class="std-cts">.+?<div class="sdt-content tnContent">.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( eeeeevevev ) [ 0 ] . replace ( ' Episodes' , '' ) . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
 eeveveVVeve = re . compile ( '<a title=".+?" href="(.+?)">.+?<div class="season">(.+?) </div>.+?<div class="episode">(.+?)</div>.+?<div class="e-name">(.+?)</div>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , IiI111111IIII , i1Ii , Iii1 in eeveveVVeve :
  Iii1 = Iii1 . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  if '</div>' in name : name = 'TBA'
  iI1ii1Ii ( '%s ' % iIi1I11I + '(%s ' % IiI111111IIII + '%s)' % i1Ii , url , 24 , iconimage , iconimage )
  if 58 - 58: VevVVe . IiiIII111ii + Veveevev
def VevevVV ( name , url , iconimage , fanart ) :
 iiiIi1 = name
 eeeeevevev = eeveevVeVeevVevVV ( url )
 I1I1 = re . compile ( '<a target="_blank" href=".+?" data-episodeid=".+?" data-linkid=".+?" data-hostname=".+?" class="watch-button" data-actuallink="(.+?)">Watch Now!</a>' ) . findall ( eeeeevevev )
 VeveVev = 1
 i1I1ii11i1Iii = [ ]
 I1IiiiiI = [ ]
 for VeVevVeveeveVVV in I1I1 :
  IIi1IiiiI1Ii = VV ( VeVevVeveeveVVV )
  if 'http' in VeVevVeveeveVVV : VVeVeVe = VeVevVeveeveVVV . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : VVeVeVe = VeVevVeveeveVVV
  name = "Link " + str ( VeveVev ) + ' | ' + VVeVeVe + IIi1IiiiI1Ii
  if VVeVeVe != 'www' :
   VeVeV ( VVeVeVe , VeVevVeveeveVVV , 2 , iconimage , fanart , description = '' )
   if 98 - 98: IiiIII111ii
def VeeeeVeveVVVV ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 iiIi11iI1iii = re . compile ( '<td height="20">(.+?)</td>.+?<td>(.+?)</td>.+?<td><a href=".+?">(.+?)</a></td>.+?<td><a href=".+?">(.+?)</a></td>.+?</tr>' , re . DOTALL ) . findall ( eeeeevevev )
 for eevVeveveVVee , name , i1I1iIi , time in iiIi11iI1iii :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( '[COLOR yellow]%s[/COLOR] - ' % i1I1iIi + '[COLOR yellow]%s[/COLOR] ' % name + '- [COLOR white]%s[/COLOR]' % eevVeveveVVee , url , 28 , iconimage , fanart )
  if 22 - 22: Veveevev * Ii11111i . i1iIIi1 * i11iIiiIii - VevVVe * iiiIi
def VVeeeevVeveev ( url ) :
 II1iI1I11I = ''
 eevVVev = xbmc . Keyboard ( II1iI1I11I , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 eevVVev . doModal ( )
 if eevVVev . isConfirmed ( ) :
  II1iI1I11I = eevVVev . getText ( ) . replace ( ' ' , '+' ) . replace ( '+and+' , '+%26+' )
 if len ( II1iI1I11I ) > 1 :
  url = 'http://www.watchepisodes4.com/search/ajax_search?q=' + II1iI1I11I
  eeeeevevev = eeveevVeVeevVevVV ( url )
  VVeVVeveeeveeV = json . loads ( eeeeevevev )
  VVeVVeveeeveeV = VVeVVeveeeveeV [ 'series' ]
  for VVVevevV in VVeVVeveeeveeV :
   VeveevVevevVeeveev = VVVevevV [ 'value' ]
   IiI11ii1I = VVVevevV [ 'seo' ]
   url = 'http://www.watchepisodes4.com/' + IiI11ii1I
   VevevVeveVVevevVevev = 'http://www.watchepisodes4.com/movie_images/' + IiI11ii1I + '.jpg'
   iI1ii1Ii ( VeveevVevevVeeveev , url , 31 , VevevVeveVVevevVevev , eeeevVV )
  II1iI1I11I = II1iI1I11I [ : - 1 ]
  eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/anewEvolvemenu/search.xml' )
  eee = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeeevevev )
  for url in eee :
   try :
    eeeeevevev = iIIIi1 ( url )
    iiI = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
    for VVVevevV in iiI :
     eeveveVVeve = re . compile ( '<title>(.+?)</title>' ) . findall ( VVVevevV )
     for iiiIi1 in eeveveVVeve :
      iiiIi1 = VeeveeVeeve ( iiiIi1 . upper ( ) )
      II1iI1I11I = II1iI1I11I . upper ( )
      if II1iI1I11I in iiiIi1 :
       eeeveVe ( VeveevVevevVeeveev , url , VevevVeveVVevevVevev , eeeevVV , VVVevevV )
   except : pass
   if 56 - 56: II1Iiii1111i . VVVevV . VevVVe
def ii111I ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 eeveveVVeve = re . compile ( '</div>.+?<a href="(.+?)" class="list cf">.+?<div class="serie-poster">.+?<img src="(.+?)" alt="(.+?)"/>.+?<span class="date">.+?</span>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , iconimage , name in eeveveVVeve :
  url = 'http://www.cinemixtv.ga/' + url
  VeVeV ( '[B][COLOR yellow]%s[/COLOR][/B]' % name , url , 52 , iconimage , fanart )
 try :
  VevVevevVe = re . compile ( '<li class="active"><a href=".+?">.+?</a></li><li class="noactive"><a href="(.+?)">(.+?)</a></li>' , re . DOTALL ) . findall ( eeeeevevev )
  for url , iiIiIiiiII in VevVevevVe :
   iI1ii1Ii ( '[COLOR cyan]Next Page >> %s[/COLOR]' % iiIiIiiiII , url , i1iI1 , '' , '' )
 except : pass
 if 33 - 33: i1iIIi1 % iiI1i1 * VevVVe
 if 95 - 95: iiiIi / iiiIi
def IIiI1Ii ( name , url , iconimage ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 eeveveVVeve = re . compile ( '<iframe width=".+?" height=".+?" src="(.+?)" allowfullscreen></iframe>' ) . findall ( eeeeevevev )
 for url in eeveveVVeve :
  eeeeevevev = eeveevVeVeevVevVV ( url )
  VeeveeveeeeevVev = 'http:' + re . compile ( '<iframe width="100%" height="100%" src="(.+?)" allowfullscreen></iframe>' ) . findall ( eeeeevevev ) [ 0 ]
  VeeveeveeeeevVev = urlresolver . HostedMediaFile ( VeeveeveeeeevVev ) . resolve ( )
  IIeevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = 'DefaultVideo.png' , thumbnailImage = iconimage )
  IIeevVeeveVeveVVevev . setPath ( VeeveeveeeeevVev )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IIeevVeeveVeveVVevev )
  if 57 - 57: eVVVeeveevV - iiiIi - VVeVeeevevee + VVeevevev
  if 30 - 30: i11IiIiiIIIII % Veveevev + Ii - VVeVeeevevee - i11IiIiiIIIII
def III11I1 ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 iiIi11iI1iii = re . compile ( '<h2 id=".+?">(.+?)</h2>.+?<p><span class="article__image article__image--undefined"><img src="(.+?)" alt=".+?"></span> </p>.+?<p><strong>(.+?)</strong>(.+?)<' , re . DOTALL ) . findall ( eeeeevevev )
 for iiiIi1 , iconimage , IIi1IIIi , i1I1iIi in iiIi11iI1iii :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( '[COLOR yellow]%s [/COLOR] ' % iiiIi1 + '[COLOR yellow]%s[/COLOR]' % IIi1IIIi + '[COLOR white]%s[/COLOR]' % i1I1iIi , url , 35 , iconimage , fanart )
def VevevVee ( name , url , iconimage , fanart ) :
 eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/Menus/Movies/EvolveLatest/mainmenu.xml' )
 iiIi11iI1iii = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in iiIi11iI1iii :
  eeeveVe ( name , url , iconimage , fanart , VVVevevV )
  if 52 - 52: VVVevV - II1Iiii1111i + VVVevV % eeveee
  if 35 - 35: iiI1i1
  if 42 - 42: iI1I . VevVVe . Ii + Veveevev + eVVVeeveevV + VevVVe
  if 31 - 31: IiiIII111ii . eVVVeeveevV - iiiIi . VeeevVVeveVV / VeeevVVeveVV
  if 56 - 56: VVeevevev / I1ii / i11iIiiIii + VeeevVVeveVV - II1Iiii1111i - VVeVeeevevee
def Iii1iiIi1II ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 60 - 60: VevVVe - I1ii * VVeVeeevevee % Veeve
def eeeIIiIiI1I ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 100 - 100: iiI1i1 + Veveevev / II1Iiii1111i . i11iIiiIii
def III1I1Iii1iiI ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="thumb">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image"' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 17 - 17: i11IiIiiIIIII % iiI1i1 - iiI1i1
def VeveevVev ( name , url , iconimage , fanarts ) :
 i1I1ii11i1Iii = [ ]
 I1IiiiiI = [ ]
 Ii1II1I11i1 = [ ]
 eeeeevevev = eeveevVeVeevVevVV ( url )
 I1I1 = re . compile ( '<a href="(.+?)" title=".+?" rel="nofollow" target="blank">.+?</a><br/>' ) . findall ( eeeeevevev )
 VeveVev = 1
 i1I1ii11i1Iii = [ ]
 I1IiiiiI = [ ]
 for VeVevVeveeveVVV in I1I1 :
  IIi1IiiiI1Ii = VV ( VeVevVeveeveVVV )
  if '//' in VeVevVeveeveVVV : VVeVeVe = VeVevVeveeveVVV . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : VVeVeVe = VeVevVeveeveVVV
  name = "Link " + str ( VeveVev ) + ' | ' + VVeVeVe + IIi1IiiiI1Ii
  if VVeVeVe != 'www' :
   VeVeV ( VVeVeVe , VeVevVeveeveVVV , 2 , iconimage , eeeevVV , description = '' )
   if 59 - 59: I1ii % iiI1i1 . Ii
   if 21 - 21: II1Iiii1111i
def II1I ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<lbscraper>(.+?)</lbscraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 10 , iconimage , fanart )
 if 29 - 29: VVeVeeevevee / Veeve / iiiIi * eVVVeeveevV
def I111i1i1111 ( name , url , iconimage , fanart ) :
 I1I1i1I = IIII1 ( name , url , iconimage )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( I1I1i1I )
 for VVVevevV in eeveveVVeve :
  eeeveVe ( name , url , iconimage , fanart , VVVevevV )
  if 10 - 10: iI1I / iiiIi + i11iIiiIii / i11IiIiiIIIII
def IIII1 ( name , url , iconimage ) :
 iiIiii1IIIII = url
 string = ''
 if url == 'mamahd' :
  eeeeevevev = eeveeeeVeveevV ( "http://mamahd.com" ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
  VVVeVeV = re . compile ( '<a href="(.+?)">.+?<img src="(.+?)"></div>.+?<div class="home cell">.+?<span>(.+?)</span>.+?<span>(.+?)</span>.+?</a>' ) . findall ( eeeeevevev )
  for url , iconimage , iIIIII1ii1I , Ii1i1iI in VVVeVeV :
   string = string + '<item>\n<title>%s vs %s</title>\n<sportsdevil>%s</sportsdevil>\n<thumbnail>%s</thumbnail>\n<fanart>fanart</fanart>\n</item>\n\n' % ( iIIIII1ii1I , Ii1i1iI , url , iconimage )
  return string
  if 16 - 16: eVVVeeveevV / II1Iiii1111i / VeeevVVeveVV * VevVVe + Ii % eVVVeeveevV
 elif url == 'cricfree' :
  eeeeevevev = eeveeeeVeveevV ( "http://cricfree.sc/football-live-stream" )
  eeeeveevev = re . compile ( '<td><span class="sport-icon(.+?)</tr>' , re . DOTALL ) . findall ( eeeeevevev )
  for eeV in eeeeveevev :
   eeveevev = re . compile ( '<td>(.+?)<br(.+?)</td>' ) . findall ( eeV )
   for IIi , i1I1iIi in eeveevev :
    IIi = '[COLOR yellow]' + IIi + '[/COLOR]'
    i1I1iIi = i1I1iIi . replace ( '>' , '' )
   time = re . compile ( '<td class="matchtime" style="color:#545454;font-weight:bold;font-size: 9px">(.+?)</td>' ) . findall ( eeV ) [ 0 ]
   time = '[COLOR white](' + time + ')[/COLOR]'
   eVeVeveveeevV = re . compile ( '<a style="text-decoration:none !important;color:#545454;" href="(.+?)" target="_blank">(.+?)</a></td>' ) . findall ( eeV )
   for url , IiiiI in eVeVeveveeevV :
    url = url
    IiiiI = IiiiI
   string = string + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( IIi + ' ' + time + ' - ' + IiiiI , url )
   string = string + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return string
  if 61 - 61: eVVVeeveevV % eVVVeeveevV * eeveee / eeveee
 elif url == 'bigsports' :
  eeeeevevev = eeveeeeVeveevV ( "http://www.bigsports.me/cat/4/football-live-stream.html" )
  VVVeVeV = re . compile ( '<td>.+?<td>(.+?)\-(.+?)\-(.+?)</td>.+?<td>(.+?)\:(.+?)</td>.+?<td>Football</td>.+?<td><strong>(.+?)</strong></td>.+?<a target=.+? href=(.+?) class=.+?' , re . DOTALL ) . findall ( eeeeevevev )
  for IIi , eeveVV , VeveevVVeveveveveee , iIIII1iIIii , eVVVeveveeveveve , name , url in VVVeVeV :
   if not '</td>' in IIi :
    url = url . replace ( '"' , '' )
    i1I1iIi = IIi + ' ' + eeveVV + ' ' + VeveevVVeveveveveee
    time = iIIII1iIIii + ':' + eVVVeveveeveveve
    i1I1iIi = '[COLOR yellow]' + i1I1iIi + '[/COLOR]'
    time = '[COLOR cyan](' + time + ')[/COLOR]'
    string = string + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( i1I1iIi + ' ' + time + ' ' + name , url )
    string = string + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return string
  if 9 - 9: I1ii + VVeVeeevevee / VVeVeeevevee
def IIII ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 Ii1I11ii1i = re . compile ( '<oktitle>(.+?)</oktitle>' ) . findall ( item ) [ 0 ]
 VeviIiIIIIIii = re . compile ( '<line1>(.+?)</line1>' ) . findall ( item ) [ 0 ]
 VVeev = re . compile ( '<line2>(.+?)</line2>' ) . findall ( item ) [ 0 ]
 ii11I1 = re . compile ( '<line3>(.+?)</line3>' ) . findall ( item ) [ 0 ]
 eVevee = '##' + Ii1I11ii1i + '#' + VeviIiIIIIIii + '#' + VVeev + '#' + ii11I1 + '##'
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 i1 ( name , eVevee , 17 , iconimage , fanart )
 if 38 - 38: VeeevVVeveVV * iiiIi % Ii11111i * Veveevev
def IIiiI ( name , url ) :
 III1i11 = re . compile ( '##(.+?)##' ) . findall ( url ) [ 0 ] . split ( '#' )
 VeeevVVeVeVev = xbmcgui . Dialog ( )
 VeeevVVeVeVev . ok ( III1i11 [ 0 ] , III1i11 [ 1 ] , III1i11 [ 2 ] , III1i11 [ 3 ] )
 if 25 - 25: VVeevevev
def Vevi1II1Iiii1I11 ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<redirect>(.+?)</redirect>' ) . findall ( item ) [ 0 ]
 Iiii ( 'name' , url , 'iconimage' , 'fanart' )
 if 24 - 24: i1iIIi1 * i11iIiiIii * eVVVeeveevV
def i1iIi ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 eVevee = re . compile ( '<text>(.+?)</text>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 i1 ( name , eVevee , 9 , iconimage , fanart )
 if 85 - 85: eeveee . Veveevev / iiiIi . Ii11111i % iI1I
def VVeveeeeveVV ( name , url ) :
 eeevevev = eeveevVeVeevVevVV ( url )
 iiVeV ( name , eeevevev )
 if 41 - 41: Ii * Veeve / VeeevVVeveVV . eVVVeeveevV
def i1IiiiI1iI ( name , url , iconimage , fanart , item ) :
 VeviII1 = re . compile ( '<image>(.+?)</image>' ) . findall ( item )
 if len ( VeviII1 ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  IIII1i = re . compile ( '<image>(.+?)</image>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  i1 ( name , IIII1i , 7 , iconimage , fanart )
 elif len ( VeviII1 ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  Ii1IIIIi1ii1I = ''
  for IIII1i in VeviII1 : Ii1IIIIi1ii1I = Ii1IIIIi1ii1I + '<image>' + IIII1i + '</image>'
  Ii1iI = eeVe
  name = VeeveeVeeve ( name )
  IiiIiI1Ii1i = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( IiiIiI1Ii1i ) : file ( IiiIiI1Ii1i , 'w' ) . close ( )
  i1iIiiiiii1II = open ( IiiIiI1Ii1i , "w" )
  i1iIiiiiii1II . write ( Ii1IIIIi1ii1I )
  i1iIiiiiii1II . close ( )
  i1 ( name , 'image' , 8 , iconimage , fanart )
  if 81 - 81: i11IiIiiIIIII * eeveee + iI1I + II1Iiii1111i - VeeevVVeveVV
def IIiIi1iI ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<iptv>(.+?)</iptv>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 6 , iconimage , fanart )
 if 32 - 32: i11IiIiiIIIII * Ii11111i
def VeveveVeeveveeve ( url , iconimage ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 VeveveVev = re . compile ( '^#.+?:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( eeeeevevev )
 VevVeevevVeVe = [ ]
 for ii1ii111 , VeveevVevevVeeveev , url in VeveveVev :
  i11111I1I = { "params" : ii1ii111 , "name" : VeveevVevevVeeveev , "url" : url }
  VevVeevevVeVe . append ( i11111I1I )
 list = [ ]
 for eevVeveveVVee in VevVeevevVeVe :
  i11111I1I = { "name" : eevVeveveVVee [ "name" ] , "url" : eevVeveveVVee [ "url" ] }
  VeveveVev = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( eevVeveveVVee [ "params" ] )
  for ii1 , VeeveveveveVe in VeveveVev :
   i11111I1I [ ii1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = VeeveveveveVe . strip ( )
  list . append ( i11111I1I )
 for eevVeveveVVee in list :
  if '.ts' in eevVeveveVVee [ "url" ] : i1 ( eevVeveveVVee [ "name" ] , eevVeveveVVee [ "url" ] , 2 , iconimage , eeeevVV )
  else : VeVeV ( eevVeveveVVee [ "name" ] , eevVeveveVVee [ "url" ] , 2 , iconimage , eeeevVV )
  if 31 - 31: VVeVeeevevee . iI1I * iiiIi + i11iIiiIii * I1ii
def eevVevVVVevVee ( name , url , iconimage , fanart , item ) :
 IIi1IiiiI1Ii = ''
 VVeveeeeveevVevVeeeee = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , i11IIIiI1I , iconimage , fanart in VVeVVeveeeveeV :
  if 'youtube.com/playlist?' in i11IIIiI1I :
   II1iI1I11I = i11IIIiI1I . split ( 'list=' ) [ 1 ]
   iI1ii1Ii ( name , i11IIIiI1I , i1iI1 , iconimage , fanart , description = II1iI1I11I )
 if len ( VVeveeeeveevVevVeeeee ) == 1 :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
  for name , url , iconimage , fanart in VVeVVeveeeveeV :
   try :
    IIi1IiiiI1Ii = VV ( url )
    eeviiiI1I1iIIIi1 = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
    if 'SportsDevil' in url : eeviiiI1I1iIIIi1 = ''
   except : pass
   if '.ts' in url : VeVeV ( name , url , 16 , iconimage , fanart , description = '' )
   if '<meta>' in item :
    i11II1I11I1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
    eeevVVeev ( name + IIi1IiiiI1Ii , url , 2 , iconimage , 10 , i11II1I11I1 , isFolder = False )
   else :
    VeVeV ( name + IIi1IiiiI1Ii , url , 2 , iconimage , fanart )
 elif len ( VVeveeeeveevVevVeeeee ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  if '.ts' in url : VeVeV ( name , url , 16 , iconimage , fanart , description = '' )
  if '<meta>' in item :
   i11II1I11I1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
   eeevVVeev ( name , url , 3 , iconimage , len ( VVeveeeeveevVevVeeeee ) , i11II1I11I1 , isFolder = True )
  else :
   iI1ii1Ii ( name , url , 3 , iconimage , fanart )
   if 17 - 17: iiI1i1 . VeeevVVeveVV / VVeVeeevevee % Veeve % Ii / i11iIiiIii
   if 58 - 58: II1Iiii1111i . Veeve + I1ii - i11iIiiIii / Veeve / Ii11111i
def i1IIIiiII1 ( name , url , iconimage , fanart , item ) :
 VVeveeeeveevVevVeeeee = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item )
 eVVeVe = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 if len ( VVeveeeeveevVevVeeeee ) + len ( eVVeVe ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item ) [ 0 ]
  url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url
  i1 ( name , url , 16 , iconimage , fanart )
 elif len ( VVeveeeeveevVevVeeeee ) + len ( eVVeVe ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  iI1ii1Ii ( name , url , 3 , iconimage , fanart )
  if 89 - 89: Veeve + Ii + Veeve
def iiIIIi ( link ) :
 if eVeveveVe == '' :
  VeeevVVeVeVev = xbmcgui . Dialog ( )
  eVeevVVeVev = VeeevVVeVeVev . yesno ( 'Adult Content' , 'You have found the goodies ;)' , '' , 'Please set a password to prevent accidental access' , 'Cancel' , 'OK' )
  if eVeevVVeVev == 1 :
   iIII1I111III = xbmc . Keyboard ( '' , 'Set Password' )
   iIII1I111III . doModal ( )
   if ( iIII1I111III . isConfirmed ( ) ) :
    IiII1II11I = iIII1I111III . getText ( )
    VevVevVVevVevVev . setSetting ( 'password' , IiII1II11I )
  else : quit ( )
 elif eVeveveVe <> '' :
  VeeevVVeVeVev = xbmcgui . Dialog ( )
  eVeevVVeVev = VeeevVVeVeVev . yesno ( 'Adult Content' , 'Please enter the password you set!' , 'to continue' , 'dirty git' , 'Cancel' , 'OK' )
  if eVeevVVeVev == 1 :
   iIII1I111III = xbmc . Keyboard ( '' , 'Enter Password' )
   iIII1I111III . doModal ( )
   if ( iIII1I111III . isConfirmed ( ) ) :
    IiII1II11I = iIII1I111III . getText ( )
   if IiII1II11I <> eVeveveVe :
    quit ( )
  else : quit ( )
  if 54 - 54: i1iIIi1 + Ii11111i + VVeVeeevevee * iI1I - eVVVeeveevV % I1ii
def I111 ( name , url , iconimage ) :
 iI1I1i11iIIii = ''
 VVeeevV = VeeveeVeeve ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , VVeeevV )
 eeeeevevev = iIIIi1 ( url )
 IIIIIiI111I = re . compile ( '<title>.*?' + re . escape ( name ) + '.*?</title>(.+?)</item>' , re . DOTALL ) . findall ( eeeeevevev ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIIIIiI111I ) [ 0 ]
 VVeveeeeveevVevVeeeee = [ ]
 if '<link>' in IIIIIiI111I :
  iIIIIIii = re . compile ( '<link>(.+?)</link>' ) . findall ( IIIIIiI111I )
  for Ii1ii111i1 in iIIIIIii :
   VVeveeeeveevVevVeeeee . append ( Ii1ii111i1 )
 if '<sportsdevil>' in IIIIIiI111I :
  i1i1i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIIIIiI111I )
  for eVeeevevev in i1i1i1I :
   eVeeevevev = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + eVeeevevev
   VVeveeeeveevVevVeeeee . append ( eVeeevevev )
 VeveVev = 1
 for eeeeevevev in VVeveeeeveevVevVeeeee :
  if '(' in eeeeevevev :
   eeeeevevev = eeeeevevev . split ( '(' )
   iI1I1i11iIIii = eeeeevevev [ 1 ] . replace ( ')' , '' )
   eeeeevevev = eeeeevevev [ 0 ]
  IIi1IiiiI1Ii = VV ( eeeeevevev )
  eeviiiI1I1iIIIi1 = eeeeevevev . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  if iI1I1i11iIIii <> '' : name = "Link " + str ( VeveVev ) + ' | ' + iI1I1i11iIIii + IIi1IiiiI1Ii
  else : name = "Link " + str ( VeveVev ) + ' | ' + eeviiiI1I1iIIIi1 + IIi1IiiiI1Ii
  VeveVev = VeveVev + 1
  eeevVVeev ( name , eeeeevevev , 2 , iconimage , 10 , '' , isFolder = False , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
  if 87 - 87: VeeevVVeveVV - eeveee / i1iIIi1 . i11iIiiIii * VeeevVVeveVV
def VVVeeveveeeveV ( name , url , iconimage , fanart , item ) :
 VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , url , iconimage , fanart in VVeVVeveeeveeV :
  if 'youtube.com/channel/' in url :
   II1iI1I11I = url . split ( 'channel/' ) [ 1 ]
   iI1ii1Ii ( name , url , i1iI1 , iconimage , fanart , description = II1iI1I11I )
  elif 'youtube.com/user/' in url :
   II1iI1I11I = url . split ( 'user/' ) [ 1 ]
   iI1ii1Ii ( name , url , i1iI1 , iconimage , fanart , description = II1iI1I11I )
  elif 'youtube.com/playlist?' in url :
   II1iI1I11I = url . split ( 'list=' ) [ 1 ]
   iI1ii1Ii ( name , url , i1iI1 , iconimage , fanart , description = II1iI1I11I )
  elif 'plugin://' in url :
   VVevev = HTMLParser ( )
   url = VVevev . unescape ( url )
   iI1ii1Ii ( name , url , i1iI1 , iconimage , fanart )
  else :
   iI1ii1Ii ( name , url , 1 , iconimage , fanart )
   if 28 - 28: I1ii - i11iIiiIii . VVVevV + i1iIIi1 / VVVevV
def i11iIiI11I1i ( ) :
 iIII1I111III = xbmc . Keyboard ( '' , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 iIII1I111III . doModal ( )
 if ( iIII1I111III . isConfirmed ( ) ) :
  II1iI1I11I = iIII1I111III . getText ( )
  II1iI1I11I = II1iI1I11I . upper ( )
 else : quit ( )
 eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/Menus/anewEvolvemenu/search.xml' )
 eee = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeeevevev )
 for VeI1Ii11I1Ii1i in eee :
  try :
   eeeeevevev = iIIIi1 ( VeI1Ii11I1Ii1i )
   iiI = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
   for VVVevevV in iiI :
    eeveveVVeve = re . compile ( '<title>(.+?)</title>' ) . findall ( VVVevevV )
    for iiiIi1 in eeveveVVeve :
     iiiIi1 = iiiIi1 . upper ( )
     if II1iI1I11I in iiiIi1 :
      eeeveVe ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV , VVVevevV )
  except : pass
  if 41 - 41: i11IiIiiIIIII
def eVVeeeveevVVVV ( url ) :
 string = "ShowPicture(%s)" % url
 xbmc . executebuiltin ( string )
 if 26 - 26: IiiIII111ii % iiI1i1 + eeveee
def VVVeee ( name , url , iconimage , description ) :
 if description : name = description
 try :
  if 'plugin://plugin.video.SportsDevil/' in url :
   VeeveveeevevevevVV ( name , url , iconimage )
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
   url = url . replace ( '|' , '' )
   VeeveveeevevevevVV ( name , url , iconimage )
  elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   VeveVVeevVe ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   VeveVVeevVe ( name , url , iconimage )
  else : VeveVVeevVe ( name , url , iconimage )
 except :
  eevevevVevevev ( ii1eVeVeveeveee ( 'Picasso' ) , 'Stream Unavailable' , '3000' , Veveveeeeeevev )
  if 86 - 86: VVVevV * Ii11111i * i1iIIi1
def eVVVeevevVeveveVe ( url ) :
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 xbmc . Player ( ) . play ( url )
 if 51 - 51: Veeve + i1iIIi1 . Ii . VVVevV + Veveevev * VevVVe
def VeveVVeevVe ( name , url , iconimage ) :
 I1II1 = True
 IIeevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; IIeevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = IIeevVeeveVeveVVevev )
 IIeevVeeveVeveVVevev . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IIeevVeeveVeveVVevev )
 if 72 - 72: I1ii + I1ii / Veeve . VeeevVVeveVV % i11IiIiiIIIII
def VeeveveeevevevevVV ( name , url , iconimage ) :
 xbmc . executebuiltin ( 'Dialog.Close(all,True)' )
 I1II1 = True
 IIeevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage ) ; IIeevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = IIeevVeeveVeveVVevev )
 xbmc . Player ( ) . play ( url , IIeevVeeveVeveVVevev , False )
 if 49 - 49: I1ii . VVeevevev - II1Iiii1111i * VeeevVVeveVV . II1Iiii1111i
def ii1Ii1IiIIi ( url ) :
 xbmc . executebuiltin ( "PlayMedia(%s)" % url )
 if 83 - 83: VVeVeeevevee / VVVevV
def iIIIi1 ( url ) :
 II1Ii11Ii1i1I = urllib2 . Request ( url )
 II1Ii11Ii1i1I . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'd2tsZGZpZXdoZjQ4NzQyNmRoNzh3ZWZ0Yw==' ) )
 ii1iIi1II = urllib2 . urlopen ( II1Ii11Ii1i1I )
 eeeeevevev = ii1iIi1II . read ( )
 ii1iIi1II . close ( )
 eeeeevevev = eeeeevevev . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 if '{' in eeeeevevev :
  string = eeeeevevev [ : : - 1 ]
  string = string . replace ( '}' , '' ) . replace ( '{' , '' ) . replace ( ',' , '' ) . replace ( ']' , '' ) . replace ( '[' , '' )
  string = string + '=='
  eeeeevevev = string . decode ( 'base64' )
 if url <> IiI : eeeeevevev = eeeeevevev . replace ( '\n' , '' ) . replace ( '\r' , '' )
 print eeeeevevev
 return eeeeevevev
 if 2 - 2: II1Iiii1111i + Veveevev - eVVVeeveevV . VevVVe - eVVVeeveevV
def eeveevVeVeevVevVV ( url ) :
 II1Ii11Ii1i1I = urllib2 . Request ( url )
 II1Ii11Ii1i1I . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'd2tsZGZpZXdoZjQ4NzQyNmRoNzh3ZWZ0Yw==' ) )
 ii1iIi1II = urllib2 . urlopen ( II1Ii11Ii1i1I )
 eeeeevevev = ii1iIi1II . read ( )
 ii1iIi1II . close ( )
 return eeeeevevev
 if 67 - 67: iiI1i1 - IiiIII111ii
def eeveeeeVeveevV ( url ) :
 II1Ii11Ii1i1I = urllib2 . Request ( url )
 II1Ii11Ii1i1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 ii1iIi1II = urllib2 . urlopen ( II1Ii11Ii1i1I )
 eeeeevevev = ii1iIi1II . read ( )
 ii1iIi1II . close ( )
 eeeeevevev = eeeeevevev . replace ( '\n' , '' ) . replace ( '\r' , '' )
 return eeeeevevev
 if 11 - 11: iiI1i1 . VeeevVVeveVV . Veeve / Ii - VVeVeeevevee
 if 30 - 30: Veveevev
def Ii111 ( ) :
 iiii ( )
 eVevi1iI = [ ]
 iieeeveevVeVVV = sys . argv [ 2 ]
 if len ( iieeeveevVeVVV ) >= 2 :
  ii1ii111 = sys . argv [ 2 ]
  eeVeveVevevVeve = ii1ii111 . replace ( '?' , '' )
  if ( ii1ii111 [ len ( ii1ii111 ) - 1 ] == '/' ) :
   ii1ii111 = ii1ii111 [ 0 : len ( ii1ii111 ) - 2 ]
  eeVVeveveVVeevevev = eeVeveVevevVeve . split ( '&' )
  eVevi1iI = { }
  for VeveVev in range ( len ( eeVVeveveVVeevevev ) ) :
   IIii11II11II1 = { }
   IIii11II11II1 = eeVVeveveVVeevevev [ VeveVev ] . split ( '=' )
   if ( len ( IIii11II11II1 ) ) == 2 :
    eVevi1iI [ IIii11II11II1 [ 0 ] ] = IIii11II11II1 [ 1 ]
 return eVevi1iI
 if 10 - 10: VevVVe / II1Iiii1111i % VVVevV * iiiIi
def eevevevVevevev ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 6 - 6: IiiIII111ii . i1iIIi1 * Veveevev . Ii
def VeeveeVeeve ( string ) :
 eVVe = re . compile ( '(\[.+?\])' ) . findall ( string )
 for I1IiIIi in eVVe : string = string . replace ( I1IiIIi , '' )
 return string
 if 42 - 42: Ii11111i . I1ii - eeveee / Ii
def ii1eVeVeveeveee ( string ) :
 string = string . split ( ' ' )
 VeeVVV = ''
 for Ii1iI11iI1 in string :
  i11 = '[B][COLOR yellow]' + Ii1iI11iI1 [ 0 ] . upper ( ) + '[/COLOR][COLOR white]' + Ii1iI11iI1 [ 1 : ] + '[/COLOR][/B] '
  VeeVVV = VeeVVV + i11
 return VeeVVV
 if 11 - 11: iI1I / Veveevev + VVeVeeevevee % iiI1i1
def eeevVVeev ( name , url , mode , iconimage , itemcount , metatype , isFolder = False , description = '' ) :
 if isFolder == True : VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 else : VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 if VVVeev == 'true' :
  II1II1iIIi11 = name
  name = VeeveeVeeve ( name )
  IiI1iII1II111 = ""
  IIiI11i1111Ii = ""
  eevevVevV = [ ]
  eVV = eval ( base64 . b64decode ( 'bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ==' ) )
  ii = { }
  if metatype == 'movie' :
   eevVIiII = name . partition ( '(' )
   if len ( eevVIiII ) > 0 :
    IiI1iII1II111 = eevVIiII [ 0 ]
    IIiI11i1111Ii = eevVIiII [ 2 ] . partition ( ')' )
   if len ( IIiI11i1111Ii ) > 0 :
    IIiI11i1111Ii = IIiI11i1111Ii [ 0 ]
   ii = eVV . get_meta ( 'movie' , name = IiI1iII1II111 , year = IIiI11i1111Ii )
   if not ii [ 'trailer' ] == '' : eevevVevV . append ( ( ii1eVeVeveeveee ( 'Play Trailer' ) , 'XBMC.RunPlugin(%s)' % VeevVee . build_plugin_url ( { 'mode' : 11 , 'url' : ii [ 'trailer' ] } ) ) )
  elif metatype == 'tvep' :
   iiiIi1 = VevVevVVevVevVev . getSetting ( 'tv' )
   if '<>' in url :
    print url
    ii1I = url . split ( '<>' ) [ 0 ]
    VVeVevev = url . split ( '<>' ) [ 1 ]
    IiI111111IIII = url . split ( '<>' ) [ 2 ]
    i1Ii = url . split ( '<>' ) [ 3 ]
    ii111iI1iIi1 = url . split ( '<>' ) [ 4 ]
    VVV = url . split ( '<>' ) [ 5 ]
    ii = eVV . get_episode_meta ( VVeVevev , imdb_id = ii1I , season = IiI111111IIII , episode = i1Ii , air_date = '' , episode_title = '' , overlay = '' )
   else :
    VeveveevevV = re . compile ( 'Season (.+?) Episode (.+?)\)' ) . findall ( name )
    for ii1iii11i1 , I11 in VeveveevevV :
     ii = eVV . get_episode_meta ( iiiIi1 , imdb_id = '' , season = ii1iii11i1 , episode = I11 , air_date = '' , episode_title = '' , overlay = '' )
  try :
   if ii [ 'cover_url' ] == '' : iconimage = iconimage
   else : iconimage = ii [ 'cover_url' ]
  except : pass
  eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( eeeevVV ) + "&iconimage=" + urllib . quote_plus ( iconimage )
  I1II1 = True
  IIeevVeeveVeveVVevev = xbmcgui . ListItem ( II1II1iIIi11 , iconImage = iconimage , thumbnailImage = iconimage )
  IIeevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = ii )
  IIeevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
  IIeevVeeveVeveVVevev . addContextMenuItems ( eevevVevV , replaceItems = False )
  if not ii . get ( 'backdrop_url' , '' ) == '' : IIeevVeeveVeveVVevev . setProperty ( 'fanart_image' , ii [ 'backdrop_url' ] )
  else : IIeevVeeveVeveVVevev . setProperty ( 'fanart_image' , eeeevVV )
  VeeveveVevV = VevVevVVevVevVev . getSetting ( 'favlist' )
  VVeeV = [ ]
  VVeeV . append ( ( ii1eVeVeveeveee ( 'Stream Information' ) , 'XBMC.Action(Info)' ) )
  if VeeveveVevV == 'yes' : VVeeV . append ( ( '[COLOR cyan]Remove From Keep Safe? [/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  else : VVeeV . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  IIeevVeeveVeveVVevev . addContextMenuItems ( VVeeV , replaceItems = False )
  I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = IIeevVeeveVeveVVevev , isFolder = isFolder , totalItems = itemcount )
  return I1II1
 else :
  if isFolder :
   iI1ii1Ii ( name , url , mode , iconimage , eeeevVV , description = '' )
  else :
   VeVeV ( name , url , mode , iconimage , eeeevVV , description = '' )
   if 79 - 79: iI1I % I1ii % eeveee % i11IiIiiIIIII - Veeve * VeeevVVeveVV
def iI1ii1Ii ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1II1 = True
 IIeevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIeevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 IIeevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 if 'youtube.com/channel/' in url :
  eeveveveveV = 'plugin://plugin.video.youtube/channel/' + description + '/'
 if 'youtube.com/user/' in url :
  eeveveveveV = 'plugin://plugin.video.youtube/user/' + description + '/'
 if 'youtube.com/playlist?' in url :
  eeveveveveV = 'plugin://plugin.video.youtube/playlist/' + description + '/'
 if 'plugin://' in url :
  eeveveveveV = url
 VVeeV = [ ]
 VeeveveVevV = VevVevVVevVevVev . getSetting ( 'favlist' )
 if VeeveveVevV == 'yes' : VVeeV . append ( ( '[COLOR cyan]Remove From Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : VVeeV . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 IIeevVeeveVeveVVevev . addContextMenuItems ( VVeeV , replaceItems = False )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = IIeevVeeveVeveVVevev , isFolder = True )
 return I1II1
 if 69 - 69: eeveee / II1Iiii1111i
def i1 ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1II1 = True
 IIeevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIeevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 VVeeV = [ ]
 VeeveveVevV = VevVevVVevVevVev . getSetting ( 'favlist' )
 if VeeveveVevV == 'yes' : VVeeV . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : VVeeV . append ( ( '[COLOR cyan]Add to Keeo Safe[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 IIeevVeeveVeveVVevev . addContextMenuItems ( VVeeV , replaceItems = False )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = IIeevVeeveVeveVVevev , isFolder = False )
 return I1II1
 if 43 - 43: VVVevV . VevVVe / VeeevVVeveVV % VeeevVVeveVV
def VeVeV ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1II1 = True
 IIeevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIeevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 IIeevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
 VVeeV = [ ]
 VeeveveVevV = VevVevVVevVevVev . getSetting ( 'favlist' )
 if VeeveveVevV == 'yes' : VVeeV . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : VVeeV . append ( ( '[COLOR cyan]Add to Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 IIeevVeeveVeveVVevev . addContextMenuItems ( VVeeV , replaceItems = False )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = IIeevVeeveVeveVVevev , isFolder = False )
 return I1II1
iiII1i1 = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvRXZvbHZlTWFpbk1lbnUueG1s' )
def I11IiI1I11i1i ( url , name ) :
 iIIIII1iiiiII = eeveevVeVeevVevVV ( url )
 if len ( iIIIII1iiiiII ) > 1 :
  Ii1iI = eeVe
  IiiIiI1Ii1i = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( IiiIiI1Ii1i ) :
   file ( IiiIiI1Ii1i , 'w' ) . close ( )
  eeeV = open ( IiiIiI1Ii1i )
  I111i1I1 = eeeV . read ( )
  if I111i1I1 == iIIIII1iiiiII : pass
  else :
   iiVeV ( '[B][COLOR yellow]PICASSO INFO[/COLOR][/B]' , iIIIII1iiiiII )
   i1iIiiiiii1II = open ( IiiIiI1Ii1i , "w" )
   i1iIiiiiii1II . write ( iIIIII1iiiiII )
   i1iIiiiiii1II . close ( )
   if 62 - 62: eVVVeeveevV * iI1I / II1Iiii1111i * eeveee
def iiVeV ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 II1Ii1iI1i1 = xbmcgui . Window ( id )
 eevVeVevevevV = 50
 while ( eevVeVevevevV > 0 ) :
  try :
   xbmc . sleep ( 10 )
   eevVeVevevevV -= 1
   II1Ii1iI1i1 . getControl ( 1 ) . setLabel ( heading )
   II1Ii1iI1i1 . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 94 - 94: Veveevev . Ii11111i / i11IiIiiIIIII . VVVevV - Ii
def iIi1III1I ( name ) :
 global Icon
 global Next
 global Previous
 global window
 global Quit
 global images
 IiiIiI1Ii1i = os . path . join ( os . path . join ( eeVe , '' ) , name + '.txt' )
 eeeV = open ( IiiIiI1Ii1i )
 I111i1I1 = eeeV . read ( )
 images = re . compile ( '<image>(.+?)</image>' ) . findall ( I111i1I1 )
 VevVevVVevVevVev . setSetting ( 'pos' , '0' )
 window = pyxbmct . AddonDialogWindow ( '' )
 eeeveeevVVVVVeV = '/resources/art'
 VeevevevevVevVVeeV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeeveeevVVVVVeV , 'next_focus.png' ) )
 VevevVVVeev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeeveeevVVVVVeV , 'next1.png' ) )
 i1111IIiii1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeeveeevVVVVVeV , 'previous_focus.png' ) )
 iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeeveeevVVVVVeV , 'previous.png' ) )
 VVVeV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeeveeevVVVVVeV , 'close_focus.png' ) )
 eVeee = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeeveeevVVVVVeV , 'close.png' ) )
 eeevevVVeVeVevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeeveeevVVVVVeV , 'main-bg1.png' ) )
 window . setGeometry ( 1300 , 720 , 100 , 50 )
 I1iii = pyxbmct . Image ( eeevevVVeVeVevev )
 window . placeControl ( I1iii , - 10 , - 10 , 130 , 70 )
 eVevee = '0xFF000000'
 Previous = pyxbmct . Button ( '' , focusTexture = i1111IIiii1 , noFocusTexture = iIi , textColor = eVevee , focusedColor = eVevee )
 Next = pyxbmct . Button ( '' , focusTexture = VeevevevevVevVVeeV , noFocusTexture = VevevVVVeev , textColor = eVevee , focusedColor = eVevee )
 Quit = pyxbmct . Button ( '' , focusTexture = VVVeV , noFocusTexture = eVeee , textColor = eVevee , focusedColor = eVevee )
 Icon = pyxbmct . Image ( images [ 0 ] , aspectRatio = 2 )
 window . placeControl ( Previous , 102 , 1 , 10 , 10 )
 window . placeControl ( Next , 102 , 40 , 10 , 10 )
 window . placeControl ( Quit , 102 , 21 , 10 , 10 )
 window . placeControl ( Icon , 0 , 0 , 100 , 50 )
 Previous . controlRight ( Next )
 Previous . controlUp ( Quit )
 window . connect ( Previous , eVVevVVevV )
 window . connect ( Next , eeveveIII11I )
 Previous . setVisible ( False )
 window . setFocus ( Quit )
 Previous . controlRight ( Quit )
 Quit . controlLeft ( Previous )
 Quit . controlRight ( Next )
 Next . controlLeft ( Quit )
 window . connect ( Quit , window . close )
 window . doModal ( )
 del window
 if 17 - 17: VeeevVVeveVV + eVVVeeveevV * VVeVeeevevee * Veveevev
def eeveveIII11I ( ) :
 iiIii1I = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 i1I11iIiII = int ( iiIii1I ) + 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( i1I11iIiII ) )
 VVevVVevVV = len ( images )
 Icon . setImage ( images [ int ( i1I11iIiII ) ] )
 Previous . setVisible ( True )
 if int ( i1I11iIiII ) == int ( VVevVVevVV ) - 1 :
  Next . setVisible ( False )
  if 61 - 61: VeeevVVeveVV . I1ii . VeeevVVeveVV / II1Iiii1111i
def eVVevVVevV ( ) :
 iiIii1I = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 eevevV = int ( iiIii1I ) - 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( eevevV ) )
 Icon . setImage ( images [ int ( eevevV ) ] )
 Next . setVisible ( True )
 if int ( eevevV ) == 0 :
  Previous . setVisible ( False )
  if 48 - 48: IiiIII111ii . i11iIiiIii
def IIieeevVV ( url , fanart ) :
 VevVevVVevVevVev . setSetting ( 'favlist' , 'yes' )
 IiiI11i1I = None
 file = open ( Ve , 'r' )
 IiiI11i1I = file . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 eeveveVVeve = re . compile ( "<item>(.+?)</item>" , re . DOTALL ) . findall ( IiiI11i1I )
 for VVVevevV in eeveveVVeve :
  eeeveVe ( VeveevVevevVeeveev , url , Veveveeeeeevev , fanart , VVVevevV )
 VevVevVVevVevVev . setSetting ( 'favlist' , 'no' )
 if 80 - 80: eVVVeeveevV / VVeVeeevevee / Veveevev + Ii - II1Iiii1111i
def iIIiiIIi1IiI ( name , url , iconimage , fanart ) :
 I11IIIiIi11 = VevVevVVevVevVev . getSetting ( 'favtype' )
 url = url . replace ( ' ' , '%20' )
 iconimage = iconimage . replace ( ' ' , '%20' )
 if '<>' in url :
  ii1I = url . split ( '<>' ) [ 0 ]
  IiI111111IIII = url . split ( '<>' ) [ 1 ]
  i1Ii = url . split ( '<>' ) [ 2 ]
  ii111iI1iIi1 = url . split ( '<>' ) [ 3 ]
  VVV = url . split ( '<>' ) [ 4 ]
  string = '<FAV><item>\n<title>' + name + '</title>\n<meta>tvep</meta>\n<nan>tvshow</nan>\n<showyear>' + ii111iI1iIi1 + '</showyear>\n<imdb>' + ii1I + '</imdb>\n<season>' + IiI111111IIII + '</season>\n<episode>' + i1Ii + '</episode>\n<episodeyear>' + VVV + '</episodeyear>\n<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 elif len ( url ) == 9 :
  string = '<FAV><item>\n<title>' + name + '</title>\n<meta>movie</meta>\n<nan>movie</nan>\n<imdb>' + url + '</imdb>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 else :
  string = '<FAV><item>\n<title>' + name + '</title>\n<' + I11IIIiIi11 + '>' + url + '</' + I11IIIiIi11 + '>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 IiII = open ( Ve , 'a' )
 IiII . write ( string )
 IiII . close ( )
 if 39 - 39: i11IiIiiIIIII % Ii11111i % Veveevev . Ii
def eVeevevVeeVeveV ( name , url , iconimage ) :
 print name
 IiiI11i1I = None
 file = open ( Ve , 'r' )
 IiiI11i1I = file . read ( )
 I1IIi = ''
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( IiiI11i1I )
 for VVeVVeveeeveeV in eeveveVVeve :
  string = '\n<FAV><item>\n' + VVeVVeveeeveeV + '</item>\n'
  if name in VVeVVeveeeveeV :
   print 'xxxxxxxxxxxxxxxxx'
   string = string . replace ( 'item' , ' ' )
  I1IIi = I1IIi + string
 file = open ( Ve , 'w' )
 file . truncate ( )
 file . write ( I1IIi )
 file . close ( )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 69 - 69: i11IiIiiIIIII + II1Iiii1111i + Veeve - VevVVe / VVeVeeevevee
def VV ( url ) :
 try :
  eeviiiI1I1iIIIi1 = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  file = open ( IIi1IiiiI1Ii , 'r' )
  VevVeveeVVV = file . read ( )
  if eeviiiI1I1iIIIi1 in VevVeveeVVV : return '[COLOR cyan] (RD)[/COLOR]'
  else : return ''
 except : return ''
 if 70 - 70: iiiIi . Ii11111i . iI1I . Ii11111i + Ii
def i1II1I ( ) :
 xbmcaddon . Addon ( 'script.module.nanscrapers' ) . openSettings ( )
 if 95 - 95: VVeevevev - eVVVeeveevV / Veeve % VVVevV . eeveee
def iii1IIII1iii11I ( ) :
 xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
 if 97 - 97: VeeevVVeveVV - iI1I
def eeeeevev ( ) :
 xbmcaddon . Addon ( 'script.module.metahandler' ) . openSettings ( )
 if 96 - 96: VVVevV % iiiIi % i11IiIiiIIIII - iiiIi % Veveevev + VVVevV
def VVevVeVeveevev ( link ) :
 try :
  iIVeevV = re . compile ( '<layouttype>(.+?)</layouttype>' ) . findall ( link ) [ 0 ]
  if iIVeevV == 'thumbnail' : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 except : pass
 if 1 - 1: Ii11111i / IiiIII111ii % iI1I . II1Iiii1111i + i1iIIi1
 if 27 - 27: iI1I % VeeevVVeveVV + i1iIIi1 % Ii / I1ii / VeeevVVeveVV
ii1ii111 = Ii111 ( ) ; VeI1Ii11I1Ii1i = None ; VeveevVevevVeeveev = None ; i1iI1 = None ; III1IiIII1 = None ; VevevVeveVVevevVevev = None ; VeveveeVe = None
try : III1IiIII1 = urllib . unquote_plus ( ii1ii111 [ "site" ] )
except : pass
try : VeI1Ii11I1Ii1i = urllib . unquote_plus ( ii1ii111 [ "url" ] )
except : pass
try : VeveevVevevVeeveev = urllib . unquote_plus ( ii1ii111 [ "name" ] )
except : pass
try : i1iI1 = int ( ii1ii111 [ "mode" ] )
except : pass
try : VevevVeveVVevevVevev = urllib . unquote_plus ( ii1ii111 [ "iconimage" ] )
except : pass
try : eeeevVV = urllib . unquote_plus ( ii1ii111 [ "fanart" ] )
except : pass
try : VeveveeVe = str ( ii1ii111 [ "description" ] )
except : pass
if 80 - 80: eeveee - eVVVeeveevV + VeeevVVeveVV
if i1iI1 == None or VeI1Ii11I1Ii1i == None or len ( VeI1Ii11I1Ii1i ) < 1 : Veeveveve ( )
elif i1iI1 == 1 : Iiii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 2 : VVVeee ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , VeveveeVe )
elif i1iI1 == 3 : I111 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 4 : VeveVVeevVe ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 5 : i11iIiI11I1i ( )
elif i1iI1 == 6 : VeveveVeeveveeve ( VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 7 : eVVeeeveevVVVV ( VeI1Ii11I1Ii1i )
elif i1iI1 == 8 : iIi1III1I ( VeveevVevevVeeveev )
elif i1iI1 == 9 : VVeveeeeveVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i )
elif i1iI1 == 10 : I111i1i1111 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 11 : ii1Ii1IiIIi ( VeI1Ii11I1Ii1i )
elif i1iI1 == 12 : iii1IIII1iii11I ( )
elif i1iI1 == 13 : eeeeevev ( )
elif i1iI1 == 15 : SCRAPEMOVIE ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 16 : VeeveveeevevevevVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 17 : IIiiI ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i )
elif i1iI1 == 18 : eeveeeVVevev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 19 : IIi11i1i1iI1 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 98 - 98: eVVVeeveevV + Ii . VevVVe - Veeve - eeveee
elif i1iI1 == 20 : iIIiiIIi1IiI ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 21 : eVeevevVeeVeveV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 22 : IIieeevVV ( VeI1Ii11I1Ii1i , eeeevVV )
elif i1iI1 == 23 : DOIPLAYER ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 24 : VevevVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 25 : i1II1I ( )
if 24 - 24: II1Iiii1111i - Ii + VVeVeeevevee
elif i1iI1 == 26 : eev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 27 : VVeveVeVVeveVVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 28 : VeveVeeveve ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 29 : VevVeeeVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 30 : VVVeveveveveV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 31 : iI1i11II1i ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 32 : VeeeeVeveVVVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 33 : VVeeeevVeveev ( VeI1Ii11I1Ii1i )
elif i1iI1 == 34 : III11I1 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 35 : VevevVee ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 38 - 38: VeeevVVeveVV / VVVevV . Ii11111i / Ii / II1Iiii1111i + iiI1i1
elif i1iI1 == 36 : eVVevevV ( )
elif i1iI1 == 37 : IiI1i ( VeI1Ii11I1Ii1i )
elif i1iI1 == 38 : VevVVVVeevV ( VeI1Ii11I1Ii1i )
elif i1iI1 == 39 : I111iI ( VeI1Ii11I1Ii1i )
elif i1iI1 == 40 : eVVVeeevVeveV ( )
elif i1iI1 == 41 : I1i1I11I ( VeI1Ii11I1Ii1i )
elif i1iI1 == 42 : VeVVeVeeeeVVe ( VeI1Ii11I1Ii1i )
if 96 - 96: IiiIII111ii
elif i1iI1 == 43 : Iii1iiIi1II ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 44 : eeeIIiIiI1I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 45 : III1I1Iii1iiI ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 46 : VeveevVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 18 - 18: IiiIII111ii * VVeVeeevevee - i11IiIiiIIIII
elif i1iI1 == 47 : DODOCLOGMENU ( )
elif i1iI1 == 48 : GET_DOCCONTENT ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , II1 )
elif i1iI1 == 49 : DO_DOCCONTENT ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , II1 )
elif i1iI1 == 50 : RESOLVE2 ( VeI1Ii11I1Ii1i )
elif i1iI1 == 51 : ii111I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 52 : IIiI1Ii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
if 31 - 31: II1Iiii1111i - Ii11111i % Veveevev % I1ii
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
