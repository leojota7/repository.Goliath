#V 2.1.1
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , requests , urllib , urllib2 , json , os , re , sys , datetime , urlresolver , random , liveresolver , base64 , pyxbmct
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
import nanscrapers
import requests
import downloader as Get_Files
import extract
import time
if 64 - 64: i11iIiiIii
VVeve = 'plugin.video.picasso'
VeevVee = Addon ( VVeve , sys . argv )
VevVevVVevVevVev = xbmcaddon . Addon ( id = VVeve )
iiiii = xbmcaddon . Addon ( ) . getAddonInfo
eeeevVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
Veveveeeeeevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'icon.png' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources/art' , 'next.png' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources' , 'rd.txt' ) )
I11i11Ii = 'http://matsbuilds.uk/pin'
eVeveveVe = xbmcaddon . Addon ( ) . getSetting ( 'password' )
VVVeev = xbmcaddon . Addon ( ) . getSetting ( 'enable_meta' )
Veeeeveveve = base64 . b64decode ( 'aHR0cHM6Ly94aGFtc3Rlci5jb20v' )
IiIi11iIIi1Ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
VeevV = requests . session ( )
IiI = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvaW5mby50eHQ=' )
eeVe = xbmc . translatePath ( 'special://home/userdata/addon_data/' + VVeve )
Ve = xbmc . translatePath ( os . path . join ( 'special://home/userdata/Database' , 'picasso.db' ) )
eevV = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'repository.Goliath' ) )
IiiIII111iI = '[COLOR cyan]Picasso[/COLOR]'
IiII = open ( Ve , 'a' )
IiII . close ( )
if 28 - 28: Ii11111i * iiI1i1
if 46 - 46: VeeevVVeveVV * Ii * Veeve
if not os . path . exists ( eevV ) :
 VVVeveeve = xbmcgui . Dialog ( ) . yesno ( IiiIII111iI , 'This Add-on requires [COLOR cyan]Goliaths Repo[/COLOR] to be installed to work correctly would you like to install it now?' , '' , yeslabel = '[B][COLOR white]YES[/COLOR][/B]' , nolabel = '[B][COLOR grey]NO[/COLOR][/B]' )
 if VVVeveeve == 1 :
  Ii1iI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  if not os . path . exists ( Ii1iI ) :
   os . makedirs ( Ii1iI )
  VeI1Ii11I1Ii1i = base64 . b64decode ( b'aHR0cDovL21hdHNidWlsZHMudWsvcmVwby9yZXBvc2l0b3J5LkdvbGlhdGgtMi4wLjAuemlw' )
  Vee = xbmcgui . DialogProgress ( )
  Vee . create ( IiiIII111iI , "" , "" , "Downloading [COLOR cyan]Goliaths Repo[/COLOR]" )
  eeveVeVeveve = os . path . join ( Ii1iI , 'repo.zip' )
  if 43 - 43: VevVVe . II1Iiii1111i
  try :
   os . remove ( eeveVeVeveve )
  except :
   pass
   if 25 - 25: VVeevevev
  Get_Files . download ( VeI1Ii11I1Ii1i , eeveVeVeveve , Vee )
  Vev = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  Vee . update ( 0 , "" , "Installing [COLOR red]Golitaths Repo[/COLOR] Please Wait" , "" )
  extract . all ( eeveVeVeveve , Vev , Vee )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  xbmc . executebuiltin ( "UpdateLocalAddons" )
  if 34 - 34: Veveevev % eeveee / VVVevV / I1ii * eVVVeeveevV + VVeVeeevevee
  if 41 - 41: i11IiIiiIIIII / IiiIII111ii / i1iIIi1
  if 50 - 50: IiIi1Iii1I1 - VevevVevVevVev
  if 75 - 75: Ii / i11IiIiiIIIII - eeveee
def ee ( ) :
 if not os . path . exists ( eeVe ) :
  os . mkdir ( eeVe )
 iii11iII ( IiI , 'GlobalCompare' )
 i1I111I ( '[B][COLOR yellow]Settings[/COLOR][/B]' , 'url' , 53 , 'http://i.imgur.com/cR0cP8f.png' , II1 )
 i1I111I ( '[B][COLOR yellow]Keep Safe[/COLOR][/B]' , 'url' , 22 , 'http://i.imgur.com/cR0cP8f.png' , II1 )
 i1I111I ( '[B][COLOR yellow]Find It...[/COLOR][/B]' , 'url' , 5 , 'http://i.imgur.com/ZQYQyHG.png' , II1 )
 i1I111I ( '[B][COLOR cyan]Movie Madness[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL01haW5tZW51LnhtbA==' ) , 26 , 'http://i.imgur.com/Y2rejnc.png' , II1 )
 i1I111I ( '[B][COLOR cyan]Telly Box[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvVHZTaG93cy9NYWlubWVudS54bWw=' ) , 27 , 'http://i.imgur.com/63LrHYW.png' , II1 )
 i11I1IIiiIi = IiIiIi ( II )
 iI = re . compile ( '<item>(.+?)</item>' ) . findall ( i11I1IIiiIi )
 for iI11iiiI1II in iI :
  VeveeeeevVeevev = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iI11iiiI1II )
  for Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV in VeveeeeevVeevev :
   i1I111I ( Ii11iii11I , VeI1Ii11I1Ii1i , 1 , eVeevevVeevevV , eeeevVV )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 43 - 43: VevVVe - IiiIII111ii * iiI1i1
def VevVeveveevVVVev ( name , url , iconimage , fanart ) :
 i1I111I ( '[B][COLOR yellow]MOVIE SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL1NlYXJjaC9TZWFyY2gudHh0' ) , 5 , 'http://i.imgur.com/QArRVYb.png' , II1 )
 i1I111I ( '[B][COLOR yellow]UK CINEMA RELEASE DATES[/COLOR][/B]' , 'http://www.empireonline.com/movies/features/upcoming-movies/' , 34 , 'http://i.imgur.com/aKQgDR7.png' , II1 )
 i11I1IIiiIi = IiIiIi ( url )
 iI = re . compile ( '<item>(.+?)</item>' ) . findall ( i11I1IIiiIi )
 Ii1iIIIi1ii = re . compile ( '<item>(.+?)</item>' ) . findall ( i11I1IIiiIi )
 for iI11iiiI1II in iI :
  VeveeeeevVeevev = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iI11iiiI1II )
 for iI11iiiI1II in Ii1iIIIi1ii :
  eeveeeveevVevevVV = re . compile ( '<title>(.+?)</title>.+?lbscraper>(.+?)</lbscraper>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iI11iiiI1II )
  for name , url , iconimage , fanart in VeveeeeevVeevev :
   eeveV ( name , url , iconimage , fanart , iI11iiiI1II )
   if 48 - 48: VVeVeeevevee + VVeVeeevevee / Veeve / iiI1i1
def i1iiI11I ( name , url , iconimage , fanarts ) :
 i1I111I ( '[B][COLOR yellow]TV SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvYW5ld0V2b2x2ZW1lbnUvc2VhcmNoLnhtbA==' ) , 33 , 'http://i.imgur.com/he5RFkL.png' , fanarts )
 i1I111I ( '[B][COLOR yellow]TV SCHEDULE[/COLOR][/B]' , 'http://www.tvwise.co.uk/uk-premiere-dates/' , 32 , 'http://i.imgur.com/XKAapZH.png' , fanarts )
 i1I111I ( '[B][COLOR yellow]Latest Episodes[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20=' ) , 28 , 'http://i.imgur.com/n8itltl.png' , fanarts )
 i1I111I ( '[B][COLOR yellow]Popular Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9wb3B1bGFyLXNlcmllcw==' ) , 29 , 'http://i.imgur.com/ury75ui.png' , fanarts )
 i1I111I ( '[B][COLOR yellow]New Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9uZXctc2VyaWVz' ) , 30 , 'http://i.imgur.com/UPWjTLw.png' , fanarts )
 if 29 - 29: VeeevVVeveVV
 iII1i1I1II = i1 ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , iII1i1I1II )
 i11I1IIiiIi = IiIiIi ( url )
 iI = re . compile ( '<item>(.+?)</item>' ) . findall ( i11I1IIiiIi )
 for iI11iiiI1II in iI :
  VeveeeeevVeevev = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iI11iiiI1II )
  for name , url , iconimage , eeeevVV in VeveeeeevVeevev :
   eeveV ( name , url , iconimage , eeeevVV , iI11iiiI1II )
   if 48 - 48: Ii11111i + Ii11111i - VVVevV . VevevVevVevVev / iiI1i1
def VeVVVeveveVVev ( name , url , iconimage , fanart ) :
 iII1i1I1II = i1 ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , iII1i1I1II )
 i11I1IIiiIi = IiIiIi ( url )
 eVee ( i11I1IIiiIi )
 if '<message>' in i11I1IIiiIi :
  IiI = re . compile ( '<message>(.+?)</message>' ) . findall ( i11I1IIiiIi ) [ 0 ]
  iii11iII ( IiI , iII1i1I1II )
 if '<intro>' in i11I1IIiiIi :
  iIii11I = re . compile ( '<intro>(.+?)</intro>' ) . findall ( i11I1IIiiIi ) [ 0 ]
  VVVevVVVevevee ( iIii11I )
 if 'XXX>yes</XXX' in i11I1IIiiIi : Iii111II ( i11I1IIiiIi )
 iI = re . compile ( '<item>(.+?)</item>' ) . findall ( i11I1IIiiIi )
 for iI11iiiI1II in iI :
  eeveV ( name , url , iconimage , fanart , iI11iiiI1II )
  if 9 - 9: VVeevevev
def eeveV ( name , url , iconimage , fanart , item ) :
 try :
  if '<sportsdevil>' in item : i11 ( name , url , iconimage , fanart , item )
  elif '<iplayer>' in item : VeveeevVVeveVVVe ( name , url , iconimage , fanart , item )
  elif '<folder>' in item : i1i1i11IIi ( name , url , iconimage , fanart , item )
  elif '<iptv>' in item : II1III ( name , url , iconimage , fanart , item )
  elif '<image>' in item : iI1iI1I1i1I ( name , url , iconimage , fanart , item )
  elif '<text>' in item : iIi11Ii1 ( name , url , iconimage , fanart , item )
  elif '<scraper>' in item : Ii11iII1 ( name , url , iconimage , fanart , item )
  elif '<lbscraper>' in item : VeevVevVeveeVevV ( name , url , iconimage , fanart , item )
  elif '<redirect>' in item : IIIIii ( name , url , iconimage , fanart , item )
  elif '<oktitle>' in item : Veveev ( name , url , iconimage , fanart , item )
  elif '<nan>' in item : VVevevVe ( name , url , iconimage , fanart , item )
  elif '<adult>' in item : VevVVVevVVeVevV ( name , url , iconimage , fanart , item )
  else : VevevVeeveveveeVev ( name , url , iconimage , fanart , item )
 except : pass
 if 100 - 100: Ii11111i + i1iIIi1 - eVVVeeveevV + i11iIiiIii * i11IiIiiIIIII
def VeveeevVVeveVVVe ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<iplayer>(.+?)</iplayer>' ) . findall ( item ) [ 0 ]
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 url = 'plugin://plugin.video.iplayerwww/?url=%s&mode=202&name=%s&iconimage=%s&description=&subtitles_url=&logged_in=False' % ( url , name , iconimage )
 iII ( name , url , 16 , iconimage , fanart )
 if 80 - 80: i1iIIi1 . I1ii
def VVevevVe ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 IIi = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 i11iIIIIIi1 = re . compile ( '<nan>(.+?)</nan>' ) . findall ( item ) [ 0 ]
 iiII1i1 = re . compile ( '<imdb>(.+?)</imdb>' ) . findall ( item ) [ 0 ]
 if i11iIIIIIi1 == 'movie' :
  iiII1i1 = iiII1i1 + '<>movie'
 elif i11iIIIIIi1 == 'tvshow' :
  eeveveVVeve = re . compile ( '<showname>(.+?)</showname>' ) . findall ( item ) [ 0 ]
  VVVevevV = re . compile ( '<season>(.+?)</season>' ) . findall ( item ) [ 0 ]
  VVeVVeveeeveeV = re . compile ( '<episode>(.+?)</episode>' ) . findall ( item ) [ 0 ]
  VeveevVevevVeeveev = re . compile ( '<showyear>(.+?)</showyear>' ) . findall ( item ) [ 0 ]
  VevevVeveVVevevVevev = re . compile ( '<episodeyear>(.+?)</episodeyear>' ) . findall ( item ) [ 0 ]
  iiII1i1 = iiII1i1 + '<>' + eeveveVVeve + '<>' + VVVevevV + '<>' + VVeVVeveeeveeV + '<>' + VeveevVevevVeeveev + '<>' + VevevVeveVVevevVevev
  i11iIIIIIi1 = "tvep"
 i1Veevev ( name , iiII1i1 , 19 , iconimage , 1 , i11iIIIIIi1 , isFolder = True )
 if 31 - 31: IiIi1Iii1I1 . Veveevev / Ii11111i
def eevevevVeve ( name , imdb , iconimage , fanart ) :
 IIi1IiiiI1Ii = ''
 iI1iII1 = name
 iII1i1I1II = i1 ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , iII1i1I1II )
 if 'movie' in imdb :
  imdb = imdb . split ( '<>' ) [ 0 ]
  eVevVVeeevVV = [ ]
  Vevii1ii1ii = [ ]
  eeeeeVeeeveee = name . partition ( '(' )
  I1I1IiI1 = eeeeeVeeeveee [ 0 ]
  I1I1IiI1 = i1 ( I1I1IiI1 )
  III1iII1I1ii = eeeeeVeeeveee [ 2 ] . partition ( ')' ) [ 0 ]
  eVVeev = nanscrapers . scrape_movie ( I1I1IiI1 , III1iII1I1ii , imdb , timeout = 800 )
 else :
  eeveveVVeve = imdb . split ( '<>' ) [ 1 ]
  eeevevVeveveV = imdb . split ( '<>' ) [ 0 ]
  VVVevevV = imdb . split ( '<>' ) [ 2 ]
  VVeVVeveeeveeV = imdb . split ( '<>' ) [ 3 ]
  VeveevVevevVeeveev = imdb . split ( '<>' ) [ 4 ]
  VevevVeveVVevevVevev = imdb . split ( '<>' ) [ 5 ]
  eVVeev = nanscrapers . scrape_episode ( eeveveVVeve , VeveevVevevVeeveev , VevevVeveVVevevVevev , VVVevevV , VVeVVeveeeveeV , eeevevVeveveV , None )
 iIiIIIi = 1
 for eeeevevVVVeeV in eVVeev ( ) :
  if type ( eeeevevVVVeeV ) != list :
   continue
  for VevevVVVeVeeevV in eeeevevVVVeeV :
   try :
    if not VevevVVVeVeeevV [ "url" ] :
     continue
    if urlresolver . HostedMediaFile ( VevevVVVeVeeevV [ 'url' ] ) . valid_url ( ) :
     IIi1IiiiI1Ii = VevevevVVeevevee ( VevevVVVeVeeevV [ 'url' ] )
     name = "Link " + str ( iIiIIIi ) + ' | ' + VevevVVVeVeeevV [ 'source' ] + IIi1IiiiI1Ii
     iIiIIIi = iIiIIIi + 1
     eeevVVe ( name , VevevVVVeVeeevV [ 'url' ] , 2 , iconimage , fanart , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
   except Exception as eeVVVevevVee :
    xbmc . log ( "error: " + repr ( eeVVVevevVee ) )
    xbmc . log ( "erro result: " + repr ( VevevVVVeVeeevV ) )
    if 16 - 16: Veeve % Veveevev - Veeve + i11IiIiiIIIII
    if 12 - 12: eVVVeeveevV / eVVVeeveevV + i11iIiiIii
def VevVVVevVVeVevV ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<adult>(.+?)</adult>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 i1I111I ( name , url , 36 , iconimage , fanart )
 if 40 - 40: VevVVe . iiI1i1 / VevVVe / i11iIiiIii
def eevVeveve ( ) :
 i1I111I ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , Veeeeveveve + 'best/weekly' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]Top Viewed[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-viewed.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]HD[/COLOR][/B]' , Veeeeveveve + 'categories/hd-videos' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]Most Commented[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-commented.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]50 Newest[/COLOR][/B]' , Veeeeveveve + 'last50.php' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]Best of 2016[/COLOR][/B]' , Veeeeveveve + 'videos/top/year/2016' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]All-time Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/alltime-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]Main Categories[/COLOR][/B]' , Veeeeveveve , 39 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]All Categories Alpha[/COLOR][/B]' , Veeeeveveve + 'categories' , 38 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 i1I111I ( '[B][COLOR yellow]Search[/COLOR][/B]' , 'url' , 40 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 87 - 87: i11iIiiIii
def VVevVeeeev ( url ) :
 VeeveVVVeVeeVe = Vevevevee ( url )
 IIi1I11I1II = re . compile ( '<div class="video"><a href="(.+?)" class=".+?"><div class=".+?"  data-previewvideo=".+?"><img src=\'(.+?)\' class=\'.+?\' alt="(.+?)"/><img class=\'.+?\' src=\'.+?\'' , re . DOTALL ) . findall ( VeeveVVVeVeeVe )
 for url , Veveveeeeeevev , Ii11iii11I in IIi1I11I1II :
  Ii11iii11I = Ii11iii11I . replace ( '&#039;' , '\'' ) . replace ( '&amp;' , ' & ' )
  VeeVeeeVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % Ii11iii11I , url , 41 , Veveveeeeeevev , eeeevVV , '' )
 ii11IIII11I = re . compile ( '<link rel="next" href="(.+?)"' , re . DOTALL ) . findall ( VeeveVVVeVeeVe )
 for url in ii11IIII11I :
  VeeVeeeVe ( '[B][COLOR cyan]Next Page>>>[/COLOR][/B]' , url , 37 , 'http://i.imgur.com/Uqrznbf.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 81 - 81: Veveevev / Ii11111i . i1iIIi1 . VevVVe
def VeVV ( url ) :
 VeeveVVVeVeeVe = Vevevevee ( url )
 IIi1I11I1II = re . compile ( '<div class="list">(.+?)<div class="head"' , re . DOTALL ) . findall ( VeeveVVVeVeeVe ) [ 1 ]
 eeVVVev = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( str ( IIi1I11I1II ) )
 for url in eeVVVev :
  Ii11iii11I = url . split ( 'xhamster.com/' ) [ 1 ]
  try :
   Ii11iii11I = Ii11iii11I . replace ( '-1.html' , '' )
   Ii11iii11I = Ii11iii11I . split ( '/' ) [ 1 ] . title ( )
  except : pass
  if 'categories' not in Ii11iii11I :
   VeeVeeeVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % Ii11iii11I , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 65 - 65: Ii11111i
def eVevevVVeVevev ( url ) :
 VeeveVVVeVeeVe = Vevevevee ( url )
 IIi1I11I1II = re . compile ( 'ul class="alphabet-block".+?<a class=""(.+?)</ul>' , re . DOTALL ) . findall ( VeeveVVVeVeeVe )
 eeVVVev = re . compile ( 'href="(.+?)">(.+?)<' , re . DOTALL ) . findall ( str ( IIi1I11I1II ) )
 for url , Ii11iii11I in eeVVVev :
  VeeVeeeVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % Ii11iii11I , url , 42 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 40 - 40: VevVVe * i11IiIiiIIIII + eVVVeeveevV % IiiIII111ii
def VVVVVeeev ( url ) :
 VeeveVVVeVeeVe = Vevevevee ( url )
 IIi1I11I1II = re . compile ( '<div class="letter-categories">(.+?)</ul>' , re . DOTALL ) . findall ( VeeveVVVeVeeVe )
 eeVVVev = re . compile ( 'href="(.+?)"><span >(.+?)<' , re . DOTALL ) . findall ( str ( IIi1I11I1II ) )
 for url , Ii11iii11I in eeVVVev :
  VeeVeeeVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % Ii11iii11I , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 49 - 49: Ii11111i . IiiIII111ii
def I1iI1iIi111i ( ) :
 iiIi1IIi1I = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 iiIi1IIi1I . doModal ( )
 if ( iiIi1IIi1I . isConfirmed ( ) ) :
  eevVeVVeveveveeVev = iiIi1IIi1I . getText ( ) . replace ( ' ' , '+' )
  VeI1Ii11I1Ii1i = Veeeeveveve + 'search.php?from=&q=' + eevVeVVeveveveeVev + '&qcat=video'
  VVevVeeeev ( VeI1Ii11I1Ii1i )
  if 56 - 56: IiiIII111ii
def Vevevevee ( url ) :
 eeeveVeveVVee = { }
 eeeveVeveVVee [ 'User-Agent' ] = IiIi11iIIi1Ii
 i11I1IIiiIi = VeevV . get ( url , headers = eeeveVeveVVee ) . text
 i11I1IIiiIi = i11I1IIiiIi . encode ( 'ascii' , 'ignore' )
 return i11I1IIiiIi
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 51 - 51: II1Iiii1111i * i11iIiiIii
def VeveeeveveevV ( url ) :
 i1I1I = [ ]
 iiI1I = [ ]
 IiIiiIIiI = ''
 VeeveVVVeVeeVe = Vevevevee ( url )
 iI = re . compile ( 'sources(.+?)debug":false' , re . DOTALL ) . findall ( VeeveVVVeVeeVe )
 eeVVevVVVVeveeev = re . compile ( '"url":"(.+?)".+?quality":"(.+?)"' , re . DOTALL ) . findall ( str ( iI ) )
 for i11I1IIiiIi , I11iiI1i1 in eeVVevVVVVeveeev :
  IiIiiIIiI = '[B][COLOR cyan]%s[/COLOR][/B]' % I11iiI1i1
  i1I1I . append ( IiIiiIIiI )
  iiI1I . append ( i11I1IIiiIi )
 if len ( eeVVevVVVVeveeev ) > 1 :
  I1i1Iiiii = xbmcgui . Dialog ( )
  VVeeveVeveveeVevev = I1i1Iiiii . select ( 'Please Select Quality' , i1I1I )
  if VVeeveVeveveeVevev == - 1 :
   return
  elif VVeeveVeveveeVevev > - 1 :
   url = iiI1I [ VVeeveVeveveeVevev ]
 else :
  url = re . compile ( 'sources.+?"url":"(.+?)"' ) . findall ( VeeveVVVeVeeVe ) [ 0 ]
 url = url . replace ( '\\' , '' )
 print 'THIS> ' + url
 eVVevVeveveVevVee = xbmcgui . ListItem ( Ii11iii11I , iconImage = 'DefaultVideo.png' , thumbnailImage = eVeevevVeevevV )
 eVVevVeveveVevVee . setInfo ( type = 'Video' , infoLabels = { "Title" : Ii11iii11I } )
 eVVevVeveveVevVee . setProperty ( "IsPlayable" , "true" )
 eVVevVeveveVevVee . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , eVVevVeveveVevVee )
 if 67 - 67: VVeevevev - eVVVeeveevV
def VeeVeeeVe ( name , url , mode , iconimage , fanart , description ) :
 iI1i11iII111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 Iii1IIII11I = True
 eVVevVeveveVevVee = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eVVevVeveveVevVee . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 eVVevVeveveVevVee . setProperty ( 'fanart_image' , fanart )
 if mode == 41 :
  eVVevVeveveVevVee . setProperty ( "IsPlayable" , "true" )
  Iii1IIII11I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1i11iII111 , listitem = eVVevVeveveVevVee , isFolder = False )
 else :
  Iii1IIII11I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1i11iII111 , listitem = eVVevVeveveVevVee , isFolder = True )
 return Iii1IIII11I
 if 77 - 77: II1Iiii1111i - Ii - VVeVeeevevee . Veveevev
 if 39 - 39: Veeve / VevevVevVevVev + IiIi1Iii1I1 / Veveevev
 if 13 - 13: i1iIIi1 + Ii11111i + IiiIII111ii % VevVVe / eeveee . i1iIIi1
def Ii11iII1 ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<scraper>(.+?)</scraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 i1I111I ( name , url , 18 , iconimage , fanart )
 if 86 - 86: I1ii * eeveee % Ii . i11IiIiiIIIII . i11iIiiIii
def eVVeeevevVeveve ( name , url , iconimage , fanart ) :
 VevVevevVe = url
 if VevVevevVe == 'latestmovies' :
  eeeeeeevVeveveve = 15
  VeV = MOVIESINDEXER ( )
  eeVevVevVeveeVVV = re . compile ( '<item>(.+?)</item>' ) . findall ( VeV )
  for iI11iiiI1II in eeVevVevVeveeVVV :
   VeveeeeevVeevev = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iI11iiiI1II )
   eVVeevVeveve = len ( eeVevVevVeveeVVV )
   for name , url , iconimage , fanart in VeveeeeevVeevev :
    if '<meta>' in iI11iiiI1II :
     iIiIi11 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( iI11iiiI1II ) [ 0 ]
     i1Veevev ( name , url , eeeeeeevVeveveve , iconimage , eVVeevVeveve , iIiIi11 , isFolder = False )
    else : eeevVVe ( name , url , 15 , iconimage , fanart )
    if 87 - 87: II1Iiii1111i . VevVVe - Veeve + Ii11111i / II1Iiii1111i / I1ii
    if 25 - 25: VevVVe . VevVVe - Veveevev % Veveevev - i11iIiiIii / IiIi1Iii1I1
def VVeV ( name , url , iconimage , fanarts ) :
 i11I1IIiiIi = VVevVevevev ( 'http://www.watchepisodes4.com' )
 iiIiI1i1 = re . compile ( '<a title=".+?" .+? style="background-image: url(.+?)"></a>.+?<div class="hb-right">.+?<a title=".+?" href="(.+?)" class="episode">(.+?)</a>' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for iconimage , url , name in iiIiI1i1 :
  iconimage = iconimage . replace ( "('" , "" ) . replace ( "')" , "" )
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  name = name . split ( '  ' ) [ 0 ]
  i1I111I ( name , url , 24 , iconimage , iconimage )
  if 69 - 69: VevevVevVevVev
def I11iII ( name , url , iconimage , fanart ) :
 i11I1IIiiIi = VVevVevevev ( url )
 iiIiI1i1 = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for url , name , iconimage in iiIiI1i1 :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  i1I111I ( name , url , 31 , iconimage , iconimage )
  if 5 - 5: VevVVe
def iIiIi11iI ( name , url , iconimage , fanart ) :
 i11I1IIiiIi = VVevVevevev ( url )
 iiIiI1i1 = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for url , name , iconimage in iiIiI1i1 :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  i1I111I ( name , url , 31 , iconimage , iconimage )
  if 83 - 83: Veeve % II1Iiii1111i % VevevVevVevVev % VVVevV
def VeVevevevVevVe ( name , url , iconimage , fanart ) :
 i11I1IIiiIi = VeeveeveeeeevVev ( url )
 VeeeeVVeeev = re . compile ( '<div class="std-cts">.+?<div class="sdt-content tnContent">.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( i11I1IIiiIi ) [ 0 ] . replace ( ' Episodes' , '' ) . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
 iI = re . compile ( '<a title=".+?" href="(.+?)">.+?<div class="season">(.+?) </div>.+?<div class="episode">(.+?)</div>.+?<div class="e-name">(.+?)</div>' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for url , VVVevevV , VVeVVeveeeveeV , i1I1IiiIi1i in iI :
  i1I1IiiIi1i = i1I1IiiIi1i . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  if '</div>' in name : name = 'TBA'
  i1I111I ( '%s ' % VeeeeVVeeev + '(%s ' % VVVevevV + '%s)' % VVeVVeveeeveeV , url , 24 , iconimage , iconimage )
  if 29 - 29: VevVVe % VevVVe
def VeevVev ( name , url , iconimage , fanart ) :
 iI1iII1 = name
 i11I1IIiiIi = VeeveeveeeeevVev ( url )
 VeeevVVeVeVev = re . compile ( '<a target="_blank" href=".+?" data-episodeid=".+?" data-linkid=".+?" data-hostname=".+?" class="watch-button" data-actuallink="(.+?)">Watch Now!</a>' ) . findall ( i11I1IIiiIi )
 iIiIIIi = 1
 eVevVVeeevVV = [ ]
 Vevii1ii1ii = [ ]
 for eVeevVVeVev in VeeevVVeVeVev :
  IIi1IiiiI1Ii = VevevevVVeevevee ( eVeevVVeVev )
  if 'http' in eVeevVVeVev : IIeevVeeveVeveVVevev = eVeevVVeVev . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : IIeevVeeveVeveVVevev = eVeevVVeVev
  name = "Link " + str ( iIiIIIi ) + ' | ' + IIeevVeeveVeveVVevev + IIi1IiiiI1Ii
  if IIeevVeeveVeveVVevev != 'www' :
   eeevVVe ( IIeevVeeveVeveVVevev , eVeevVVeVev , 2 , iconimage , fanart , description = '' )
   if 92 - 92: VeeevVVeveVV * IiIi1Iii1I1
def eeveveveveV ( name , url , iconimage , fanart ) :
 i11I1IIiiIi = VeeveeveeeeevVev ( url )
 iiIiI1i1 = re . compile ( '<td height="20">(.+?)</td>.+?<td>(.+?)</td>.+?<td><a href=".+?">(.+?)</a></td>.+?<td><a href=".+?">(.+?)</a></td>.+?</tr>' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for I1II1 , name , eeeV , time in iiIiI1i1 :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  i1I111I ( '[COLOR yellow]%s[/COLOR] - ' % eeeV + '[COLOR yellow]%s[/COLOR] ' % name + '- [COLOR white]%s[/COLOR]' % I1II1 , url , 28 , iconimage , fanart )
  if 26 - 26: i11IiIiiIIIII % VVVevV
def eevevVeeveeeeee ( url ) :
 VeveVev = ''
 iII11 = xbmc . Keyboard ( VeveVev , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 iII11 . doModal ( )
 if iII11 . isConfirmed ( ) :
  VeveVev = iII11 . getText ( ) . replace ( ' ' , '+' ) . replace ( '+and+' , '+%26+' )
 if len ( VeveVev ) > 1 :
  url = 'http://www.watchepisodes4.com/search/ajax_search?q=' + VeveVev
  i11I1IIiiIi = VeeveeveeeeevVev ( url )
  VeveeeeevVeevev = json . loads ( i11I1IIiiIi )
  VeveeeeevVeevev = VeveeeeevVeevev [ 'series' ]
  for iI11iiiI1II in VeveeeeevVeevev :
   Ii11iii11I = iI11iiiI1II [ 'value' ]
   iiIiii1IIIII = iI11iiiI1II [ 'seo' ]
   url = 'http://www.watchepisodes4.com/' + iiIiii1IIIII
   eVeevevVeevevV = 'http://www.watchepisodes4.com/movie_images/' + iiIiii1IIIII + '.jpg'
   i1I111I ( Ii11iii11I , url , 31 , eVeevevVeevevV , eeeevVV )
  VeveVev = VeveVev [ : - 1 ]
  i11I1IIiiIi = IiIiIi ( 'http://matsbuilds.uk/anewEvolvemenu/search.xml' )
  eeveve = re . compile ( '<link>(.+?)</link>' ) . findall ( i11I1IIiiIi )
  for url in eeveve :
   try :
    i11I1IIiiIi = IiIiIi ( url )
    IIIIiiIiiI = re . compile ( '<item>(.+?)</item>' ) . findall ( i11I1IIiiIi )
    for iI11iiiI1II in IIIIiiIiiI :
     iI = re . compile ( '<title>(.+?)</title>' ) . findall ( iI11iiiI1II )
     for iI1iII1 in iI :
      iI1iII1 = i1 ( iI1iII1 . upper ( ) )
      VeveVev = VeveVev . upper ( )
      if VeveVev in iI1iII1 :
       eeveV ( Ii11iii11I , url , eVeevevVeevevV , eeeevVV , iI11iiiI1II )
   except : pass
   if 10 - 10: Veveevev % Veveevev - Veveevev . IiiIII111ii
def eevVeVeeveveeve ( name , url , iconimage , fanart ) :
 i11I1IIiiIi = VeeveeveeeeevVev ( url )
 iI = re . compile ( '</div>.+?<a href="(.+?)" class="list cf">.+?<div class="serie-poster">.+?<img src="(.+?)" alt="(.+?)"/>.+?<span class="date">.+?</span>' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for url , iconimage , name in iI :
  url = 'http://www.cinemixtv.ga/' + url
  eeevVVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % name , url , 52 , iconimage , fanart )
 try :
  ii11IIII11I = re . compile ( '<li class="active"><a href=".+?">.+?</a></li><li class="noactive"><a href="(.+?)">(.+?)</a></li>' , re . DOTALL ) . findall ( i11I1IIiiIi )
  for url , I1II1I11I1I in ii11IIII11I :
   i1I111I ( '[COLOR cyan]Next Page >> %s[/COLOR]' % I1II1I11I1I , url , VeVVeve , '' , '' )
 except : pass
 if 1 - 1: Veeve
 if 68 - 68: IiiIII111ii - VevVVe / IiIi1Iii1I1 / VVeVeeevevee
def I11iiii ( name , url , iconimage ) :
 i11I1IIiiIi = VeeveeveeeeevVev ( url )
 iI = re . compile ( '<iframe width=".+?" height=".+?" src="(.+?)" allowfullscreen></iframe>' ) . findall ( i11I1IIiiIi )
 for url in iI :
  i11I1IIiiIi = VeeveeveeeeevVev ( url )
  iiI1I = 'http:' + re . compile ( '<iframe width="100%" height="100%" src="(.+?)" allowfullscreen></iframe>' ) . findall ( i11I1IIiiIi ) [ 0 ]
  iiI1I = urlresolver . HostedMediaFile ( iiI1I ) . resolve ( )
  eVVevVeveveVevVee = xbmcgui . ListItem ( name , iconImage = 'DefaultVideo.png' , thumbnailImage = iconimage )
  eVVevVeveveVevVee . setPath ( iiI1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , eVVevVeveveVevVee )
  if 60 - 60: VVeVeeevevee . Ii + i1iIIi1 / eeveee . Veeve
  if 82 - 82: VVVevV / VevVVe % iiI1i1 / Ii - VevVVe
def I1III1111iIi ( name , url , iconimage , fanart ) :
 i11I1IIiiIi = VeeveeveeeeevVev ( url )
 iiIiI1i1 = re . compile ( '<h2 id=".+?">(.+?)</h2>.+?<p><span class="article__image article__image--undefined"><img src="(.+?)" alt=".+?"></span> </p>.+?<p><strong>(.+?)</strong>(.+?)<' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for iI1iII1 , iconimage , I1i111I , eeeV in iiIiI1i1 :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  i1I111I ( '[COLOR yellow]%s [/COLOR] ' % iI1iII1 + '[COLOR yellow]%s[/COLOR]' % I1i111I + '[COLOR white]%s[/COLOR]' % eeeV , url , 35 , iconimage , fanart )
def VeeVeeveeevVeveevevV ( name , url , iconimage , fanart ) :
 i11I1IIiiIi = IiIiIi ( 'http://matsbuilds.uk/Menus/Movies/EvolveLatest/mainmenu.xml' )
 iiIiI1i1 = re . compile ( '<item>(.+?)</item>' ) . findall ( i11I1IIiiIi )
 for iI11iiiI1II in iiIiI1i1 :
  eeveV ( name , url , iconimage , fanart , iI11iiiI1II )
  if 48 - 48: VevevVevVevVev / IiIi1Iii1I1 . iiI1i1 * Veveevev * I1ii / Ii
  if 92 - 92: II1Iiii1111i % II1Iiii1111i - eeveee / Veveevev
  if 10 - 10: IiiIII111ii + II1Iiii1111i * VVVevV + iiI1i1 / IiIi1Iii1I1 / VVVevV
  if 42 - 42: VevVVe
  if 38 - 38: eVVVeeveevV + Veeve % VevevVevVevVev % Veveevev - i11IiIiiIIIII / VeeevVVeveVV
def eVVeeevevevevVeveev ( name , url , iconimage , fanarts ) :
 i11I1IIiiIi = VVevVevevev ( url )
 iiIiI1i1 = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for url , name , iconimage in iiIiI1i1 :
  i1I111I ( name , url , 46 , iconimage , iconimage )
  if 1 - 1: I1ii + I1ii % Veveevev + i11iIiiIii
def eeeveevevevev ( name , url , iconimage , fanarts ) :
 i11I1IIiiIi = VVevVevevev ( url )
 iiIiI1i1 = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for url , name , iconimage in iiIiI1i1 :
  i1I111I ( name , url , 46 , iconimage , iconimage )
  if 11 - 11: iiI1i1
def IiIIII1i11I ( name , url , iconimage , fanarts ) :
 i11I1IIiiIi = VVevVevevev ( url )
 iiIiI1i1 = re . compile ( '<div class="thumb">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image"' , re . DOTALL ) . findall ( i11I1IIiiIi )
 for url , name , iconimage in iiIiI1i1 :
  i1I111I ( name , url , 46 , iconimage , iconimage )
  if 86 - 86: II1Iiii1111i . Ii11111i - VeeevVVeveVV . VVeevevev + i11IiIiiIIIII
def VVe ( name , url , iconimage , fanarts ) :
 eVevVVeeevVV = [ ]
 Vevii1ii1ii = [ ]
 IIii11Ii1i1I = [ ]
 i11I1IIiiIi = VeeveeveeeeevVev ( url )
 VeeevVVeVeVev = re . compile ( '<a href="(.+?)" title=".+?" rel="nofollow" target="blank">.+?</a><br/>' ) . findall ( i11I1IIiiIi )
 iIiIIIi = 1
 eVevVVeeevVV = [ ]
 Vevii1ii1ii = [ ]
 for eVeevVVeVev in VeeevVVeVeVev :
  IIi1IiiiI1Ii = VevevevVVeevevee ( eVeevVVeVev )
  if '//' in eVeevVVeVev : IIeevVeeveVeveVVevev = eVeevVVeVev . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : IIeevVeeveVeveVVevev = eVeevVVeVev
  name = "Link " + str ( iIiIIIi ) + ' | ' + IIeevVeeveVeveVVevev + IIi1IiiiI1Ii
  if IIeevVeeveVeveVVevev != 'www' :
   eeevVVe ( IIeevVeeveVeveVVevev , eVeevVVeVev , 2 , iconimage , eeeevVV , description = '' )
   if 76 - 76: Ii11111i + Ii . II1Iiii1111i * VevVVe * i11IiIiiIIIII
   if 14 - 14: eeveee % Ii11111i * IiiIII111ii + i11IiIiiIIIII + II1Iiii1111i * i11IiIiiIIIII
def VeevVevVeveeVevV ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<lbscraper>(.+?)</lbscraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 i1I111I ( name , url , 10 , iconimage , fanart )
 if 3 - 3: Veveevev * II1Iiii1111i
def eVeVeveveeevV ( name , url , iconimage , fanart ) :
 eVVeev = eee ( name , url , iconimage )
 iI = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( eVVeev )
 for iI11iiiI1II in iI :
  eeveV ( name , url , iconimage , fanart , iI11iiiI1II )
  if 36 - 36: VeeevVVeveVV . VVeevevev
def eee ( name , url , iconimage ) :
 VevVevevVe = url
 eV = ''
 if url == 'mamahd' :
  i11I1IIiiIi = VVevVevevev ( "http://mamahd.com" ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
  IIiIi = re . compile ( '<a href="(.+?)">.+?<img src="(.+?)"></div>.+?<div class="home cell">.+?<span>(.+?)</span>.+?<span>(.+?)</span>.+?</a>' ) . findall ( i11I1IIiiIi )
  for url , iconimage , VVeVeeVeVVVee , Iiii1iI1i in IIiIi :
   eV = eV + '<item>\n<title>%s vs %s</title>\n<sportsdevil>%s</sportsdevil>\n<thumbnail>%s</thumbnail>\n<fanart>fanart</fanart>\n</item>\n\n' % ( VVeVeeVeVVVee , Iiii1iI1i , url , iconimage )
  return eV
  if 34 - 34: VevevVevVevVev * VevVVe . Ii * VevevVevVevVev / VevevVevVevVev
 elif url == 'cricfree' :
  i11I1IIiiIi = VVevVevevev ( "http://cricfree.sc/football-live-stream" )
  IIiI1Ii = re . compile ( '<td><span class="sport-icon(.+?)</tr>' , re . DOTALL ) . findall ( i11I1IIiiIi )
  for VevVevVevVe in IIiI1Ii :
   VVVVeVeveveevV = re . compile ( '<td>(.+?)<br(.+?)</td>' ) . findall ( VevVevVevVe )
   for I1I1I1IIi1III , eeeV in VVVVeVeveveevV :
    I1I1I1IIi1III = '[COLOR yellow]' + I1I1I1IIi1III + '[/COLOR]'
    eeeV = eeeV . replace ( '>' , '' )
   time = re . compile ( '<td class="matchtime" style="color:#545454;font-weight:bold;font-size: 9px">(.+?)</td>' ) . findall ( VevVevVevVe ) [ 0 ]
   time = '[COLOR white](' + time + ')[/COLOR]'
   II11IiiIII = re . compile ( '<a style="text-decoration:none !important;color:#545454;" href="(.+?)" target="_blank">(.+?)</a></td>' ) . findall ( VevVevVevVe )
   for url , eevVVVe in II11IiiIII :
    url = url
    eevVVVe = eevVVVe
   eV = eV + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( I1I1I1IIi1III + ' ' + time + ' - ' + eevVVVe , url )
   eV = eV + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return eV
  if 11 - 11: iiI1i1 * iiI1i1 * VevVVe
 elif url == 'bigsports' :
  i11I1IIiiIi = VVevVevevev ( "http://www.bigsports.me/cat/4/football-live-stream.html" )
  IIiIi = re . compile ( '<td>.+?<td>(.+?)\-(.+?)\-(.+?)</td>.+?<td>(.+?)\:(.+?)</td>.+?<td>Football</td>.+?<td><strong>(.+?)</strong></td>.+?<a target=.+? href=(.+?) class=.+?' , re . DOTALL ) . findall ( i11I1IIiiIi )
  for I1I1I1IIi1III , iII1ii1 , I1i1iiiI1 , iIIi , eVeveeveveeev , name , url in IIiIi :
   if not '</td>' in I1I1I1IIi1III :
    url = url . replace ( '"' , '' )
    eeeV = I1I1I1IIi1III + ' ' + iII1ii1 + ' ' + I1i1iiiI1
    time = iIIi + ':' + eVeveeveveeev
    eeeV = '[COLOR yellow]' + eeeV + '[/COLOR]'
    time = '[COLOR cyan](' + time + ')[/COLOR]'
    eV = eV + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( eeeV + ' ' + time + ' ' + name , url )
    eV = eV + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return eV
  if 19 - 19: Veeve + i1iIIi1
  if 53 - 53: I1ii - VevVVe - I1ii * IiiIII111ii
def Veveev ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 eeeeeeevVV = re . compile ( '<oktitle>(.+?)</oktitle>' ) . findall ( item ) [ 0 ]
 iI1I = re . compile ( '<line1>(.+?)</line1>' ) . findall ( item ) [ 0 ]
 VeeVeVe = re . compile ( '<line2>(.+?)</line2>' ) . findall ( item ) [ 0 ]
 III1I1Iii1iiI = re . compile ( '<line3>(.+?)</line3>' ) . findall ( item ) [ 0 ]
 i1Iii11I1i = '##' + eeeeeeevVV + '#' + iI1I + '#' + VeeVeVe + '#' + III1I1Iii1iiI + '##'
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iII ( name , i1Iii11I1i , 17 , iconimage , fanart )
 if 72 - 72: iiI1i1 * i11IiIiiIIIII % VevevVevVevVev / VVeevevev
def I11i1II ( name , url ) :
 VeeiiIi1i = re . compile ( '##(.+?)##' ) . findall ( url ) [ 0 ] . split ( '#' )
 I1i1Iiiii = xbmcgui . Dialog ( )
 I1i1Iiiii . ok ( VeeiiIi1i [ 0 ] , VeeiiIi1i [ 1 ] , VeeiiIi1i [ 2 ] , VeeiiIi1i [ 3 ] )
 if 27 - 27: eVVVeeveevV * VevevVevVevVev . IiIi1Iii1I1 % i1iIIi1 * i1iIIi1 . Ii
def IIIIii ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<redirect>(.+?)</redirect>' ) . findall ( item ) [ 0 ]
 VeVVVeveveVVev ( 'name' , url , 'iconimage' , 'fanart' )
 if 72 - 72: eVVVeeveevV % VVVevV + VVeevevev / I1ii + i1iIIi1
def iIi11Ii1 ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 i1Iii11I1i = re . compile ( '<text>(.+?)</text>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iII ( name , i1Iii11I1i , 9 , iconimage , fanart )
 if 10 - 10: IiIi1Iii1I1 / VevevVevVevVev + i11iIiiIii / i11IiIiiIIIII
def VVVeVeV ( name , url ) :
 iIIIII1ii1I = VeeveeveeeeevVev ( url )
 Ii1i1iI ( name , iIIIII1ii1I )
 if 16 - 16: eVVVeeveevV / II1Iiii1111i / VeeevVVeveVV * VevVVe + Ii % eVVVeeveevV
def iI1iI1I1i1I ( name , url , iconimage , fanart , item ) :
 eeeeveevev = re . compile ( '<image>(.+?)</image>' ) . findall ( item )
 if len ( eeeeveevev ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  eeV = re . compile ( '<image>(.+?)</image>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  iII ( name , eeV , 7 , iconimage , fanart )
 elif len ( eeeeveevev ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  eeveevev = ''
  for eeV in eeeeveevev : eeveevev = eeveevev + '<image>' + eeV + '</image>'
  Ii1iI = eeVe
  name = i1 ( name )
  IIieVeVeveveeevV = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( IIieVeVeveveeevV ) : file ( IIieVeVeveveeevV , 'w' ) . close ( )
  IiiiI = open ( IIieVeVeveveeevV , "w" )
  IiiiI . write ( eeveevev )
  IiiiI . close ( )
  iII ( name , 'image' , 8 , iconimage , fanart )
  if 61 - 61: eVVVeeveevV % eVVVeeveevV * eeveee / eeveee
def II1III ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<iptv>(.+?)</iptv>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 i1I111I ( name , url , 6 , iconimage , fanart )
 if 75 - 75: i1iIIi1 . VevevVevVevVev
def iII111i ( url , iconimage ) :
 i11I1IIiiIi = VeeveeveeeeevVev ( url )
 Veveveveve = re . compile ( '^#.+?:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i11I1IIiiIi )
 ii = [ ]
 for VVVeveVVee , Ii11iii11I , url in Veveveveve :
  eVVVeveveeveveve = { "params" : VVVeveVVee , "name" : Ii11iii11I , "url" : url }
  ii . append ( eVVVeveveeveveve )
 list = [ ]
 for I1II1 in ii :
  eVVVeveveeveveve = { "name" : I1II1 [ "name" ] , "url" : I1II1 [ "url" ] }
  Veveveveve = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1II1 [ "params" ] )
  for iIi11i1 , eVeveveeeveeveveeve in Veveveveve :
   eVVVeveveeveveve [ iIi11i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = eVeveveeeveeveveeve . strip ( )
  list . append ( eVVVeveveeveveve )
 for I1II1 in list :
  if '.ts' in I1II1 [ "url" ] : iII ( I1II1 [ "name" ] , I1II1 [ "url" ] , 2 , iconimage , eeeevVV )
  else : eeevVVe ( I1II1 [ "name" ] , I1II1 [ "url" ] , 2 , iconimage , eeeevVV )
  if 7 - 7: Ii11111i - II1Iiii1111i + VVVevV + Veeve + iiI1i1
def VevevVeeveveveeVev ( name , url , iconimage , fanart , item ) :
 IIi1IiiiI1Ii = ''
 VVeev = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 VeveeeeevVeevev = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , ii11I1 , iconimage , fanart in VeveeeeevVeevev :
  if 'youtube.com/playlist?' in ii11I1 :
   VeveVev = ii11I1 . split ( 'list=' ) [ 1 ]
   i1I111I ( name , ii11I1 , VeVVeve , iconimage , fanart , description = VeveVev )
 if len ( VVeev ) == 1 :
  VeveeeeevVeevev = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
  for name , url , iconimage , fanart in VeveeeeevVeevev :
   try :
    IIi1IiiiI1Ii = VevevevVVeevevee ( url )
    eVevee = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
    if 'SportsDevil' in url : eVevee = ''
   except : pass
   if '.ts' in url : eeevVVe ( name , url , 16 , iconimage , fanart , description = '' )
   if '<meta>' in item :
    iIiIi11 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
    i1Veevev ( name + IIi1IiiiI1Ii , url , 2 , iconimage , 10 , iIiIi11 , isFolder = False )
   else :
    eeevVVe ( name + IIi1IiiiI1Ii , url , 2 , iconimage , fanart )
 elif len ( VVeev ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  if '.ts' in url : eeevVVe ( name , url , 16 , iconimage , fanart , description = '' )
  if '<meta>' in item :
   iIiIi11 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
   i1Veevev ( name , url , 3 , iconimage , len ( VVeev ) , iIiIi11 , isFolder = True )
  else :
   i1I111I ( name , url , 3 , iconimage , fanart )
   if 38 - 38: VeeevVVeveVV * VevevVevVevVev % Ii11111i * Veveevev
   if 29 - 29: VVVevV / Ii . VevVVe - Veveevev - Veveevev - i11IiIiiIIIII
def i11 ( name , url , iconimage , fanart , item ) :
 VVeev = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item )
 IiiIiI111iI = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 if len ( VVeev ) + len ( IiiIiI111iI ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item ) [ 0 ]
  url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url
  iII ( name , url , 16 , iconimage , fanart )
 elif len ( VVeev ) + len ( IiiIiI111iI ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  i1I111I ( name , url , 3 , iconimage , fanart )
  if 85 - 85: eeveee . Veveevev / VevevVevVevVev . Ii11111i % IiIi1Iii1I1
def Iii111II ( link ) :
 if eVeveveVe == '' :
  I1i1Iiiii = xbmcgui . Dialog ( )
  VVeeveVeveveeVevev = I1i1Iiiii . yesno ( 'Adult Content' , 'You have found the goodies ;)' , '' , 'Please set a password to prevent accidental access' , 'Cancel' , 'OK' )
  if VVeeveVeveveeVevev == 1 :
   iiIi1IIi1I = xbmc . Keyboard ( '' , 'Set Password' )
   iiIi1IIi1I . doModal ( )
   if ( iiIi1IIi1I . isConfirmed ( ) ) :
    VVeveeeeveVV = iiIi1IIi1I . getText ( )
    VevVevVVevVevVev . setSetting ( 'password' , VVeveeeeveVV )
  else : quit ( )
 elif eVeveveVe <> '' :
  I1i1Iiiii = xbmcgui . Dialog ( )
  VVeeveVeveveeVevev = I1i1Iiiii . yesno ( 'Adult Content' , 'Please enter the password you set!' , 'to continue' , 'dirty git' , 'Cancel' , 'OK' )
  if VVeeveVeveveeVevev == 1 :
   iiIi1IIi1I = xbmc . Keyboard ( '' , 'Enter Password' )
   iiIi1IIi1I . doModal ( )
   if ( iiIi1IIi1I . isConfirmed ( ) ) :
    VVeveeeeveVV = iiIi1IIi1I . getText ( )
   if VVeveeeeveVV <> eVeveveVe :
    quit ( )
  else : quit ( )
  if 97 - 97: VevVVe / IiiIII111ii
def Veeeev ( name , url , iconimage ) :
 eVV = ''
 iII1i1I1II = i1 ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , iII1i1I1II )
 i11I1IIiiIi = IiIiIi ( url )
 Veee = re . compile ( '<title>.*?' + re . escape ( name ) + '.*?</title>(.+?)</item>' , re . DOTALL ) . findall ( i11I1IIiiIi ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Veee ) [ 0 ]
 VVeev = [ ]
 if '<link>' in Veee :
  I1i1iiiII1i = re . compile ( '<link>(.+?)</link>' ) . findall ( Veee )
  for eVeveVev in I1i1iiiII1i :
   VVeev . append ( eVeveVev )
 if '<sportsdevil>' in Veee :
  i1i1IIIIi1i = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Veee )
  for Ii11iiI in i1i1IIIIi1i :
   Ii11iiI = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + Ii11iiI
   VVeev . append ( Ii11iiI )
 iIiIIIi = 1
 for i11I1IIiiIi in VVeev :
  if '(' in i11I1IIiiIi :
   i11I1IIiiIi = i11I1IIiiIi . split ( '(' )
   eVV = i11I1IIiiIi [ 1 ] . replace ( ')' , '' )
   i11I1IIiiIi = i11I1IIiiIi [ 0 ]
  IIi1IiiiI1Ii = VevevevVVeevevee ( i11I1IIiiIi )
  eVevee = i11I1IIiiIi . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  if eVV <> '' : name = "Link " + str ( iIiIIIi ) + ' | ' + eVV + IIi1IiiiI1Ii
  else : name = "Link " + str ( iIiIIIi ) + ' | ' + eVevee + IIi1IiiiI1Ii
  iIiIIIi = iIiIIIi + 1
  i1Veevev ( name , i11I1IIiiIi , 2 , iconimage , 10 , '' , isFolder = False , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
  if 17 - 17: II1Iiii1111i % eVVVeeveevV . Ii / VeeevVVeveVV
def i1i1i11IIi ( name , url , iconimage , fanart , item ) :
 VeveeeeevVeevev = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , url , iconimage , fanart in VeveeeeevVeevev :
  if 'youtube.com/channel/' in url :
   VeveVev = url . split ( 'channel/' ) [ 1 ]
   i1I111I ( name , url , VeVVeve , iconimage , fanart , description = VeveVev )
  elif 'youtube.com/user/' in url :
   VeveVev = url . split ( 'user/' ) [ 1 ]
   i1I111I ( name , url , VeVVeve , iconimage , fanart , description = VeveVev )
  elif 'youtube.com/playlist?' in url :
   VeveVev = url . split ( 'list=' ) [ 1 ]
   i1I111I ( name , url , VeVVeve , iconimage , fanart , description = VeveVev )
  elif 'plugin://' in url :
   IIiIiiii = HTMLParser ( )
   url = IIiIiiii . unescape ( url )
   i1I111I ( name , url , VeVVeve , iconimage , fanart )
  else :
   i1I111I ( name , url , 1 , iconimage , fanart )
   if 89 - 89: IiiIII111ii - VevevVevVevVev % II1Iiii1111i % eeveee
def IIiii11i ( ) :
 iiIi1IIi1I = xbmc . Keyboard ( '' , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 iiIi1IIi1I . doModal ( )
 if ( iiIi1IIi1I . isConfirmed ( ) ) :
  VeveVev = iiIi1IIi1I . getText ( )
  VeveVev = VeveVev . upper ( )
 else : quit ( )
 i11I1IIiiIi = IiIiIi ( 'http://matsbuilds.uk/Menus/anewEvolvemenu/search.xml' )
 eeveve = re . compile ( '<link>(.+?)</link>' ) . findall ( i11I1IIiiIi )
 for VeI1Ii11I1Ii1i in eeveve :
  try :
   i11I1IIiiIi = IiIiIi ( VeI1Ii11I1Ii1i )
   IIIIiiIiiI = re . compile ( '<item>(.+?)</item>' ) . findall ( i11I1IIiiIi )
   for iI11iiiI1II in IIIIiiIiiI :
    iI = re . compile ( '<title>(.+?)</title>' ) . findall ( iI11iiiI1II )
    for iI1iII1 in iI :
     iI1iII1 = iI1iII1 . upper ( )
     if VeveVev in iI1iII1 :
      eeveV ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV , iI11iiiI1II )
  except : pass
  if 100 - 100: VevevVevVevVev % iiI1i1 * Veeve - IiiIII111ii
def eeevevVeveveVeveveve ( url ) :
 eV = "ShowPicture(%s)" % url
 xbmc . executebuiltin ( eV )
 if 71 - 71: VVVevV - VevevVevVevVev / Veveevev * Veveevev / Ii . Ii
def eeeeveveveeVevevevev ( name , url , iconimage , description ) :
 if description : name = description
 try :
  if 'plugin://plugin.video.SportsDevil/' in url :
   eVeeeeevevevVeevev ( name , url , iconimage )
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
   url = url . replace ( '|' , '' )
   eVeeeeevevevVeevev ( name , url , iconimage )
  elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   VVee ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   VVee ( name , url , iconimage )
  else : VVee ( name , url , iconimage )
 except :
  eevevVeveveVevev ( Ii1i1i1i1I1Ii ( 'Picasso' ) , 'Stream Unavailable' , '3000' , Veveveeeeeevev )
  if 25 - 25: Veeve
def VVVevVVVevevee ( url ) :
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 xbmc . Player ( ) . play ( url )
 if 11 - 11: II1Iiii1111i
def VVee ( name , url , iconimage ) :
 Iii1IIII11I = True
 eVVevVeveveVevVee = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; eVVevVeveveVevVee . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Iii1IIII11I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = eVVevVeveveVevVee )
 eVVevVeveveVevVee . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , eVVevVeveveVevVee )
 if 74 - 74: Veveevev * eeveee + Veveevev . eVVVeeveevV * VeeevVVeveVV % Ii11111i
def eVeeeeevevevVeevev ( name , url , iconimage ) :
 xbmc . executebuiltin ( 'Dialog.Close(all,True)' )
 Iii1IIII11I = True
 eVVevVeveveVevVee = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage ) ; eVVevVeveveVevVee . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Iii1IIII11I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = eVVevVeveveVevVee )
 xbmc . Player ( ) . play ( url , eVVevVeveveVevVee , False )
 if 85 - 85: VevevVevVevVev / Ii11111i
def iI1iIIIi1i ( url ) :
 xbmc . executebuiltin ( "PlayMedia(%s)" % url )
 if 89 - 89: iiI1i1
def IiIiIi ( url ) :
 i11iiiiI1i = urllib2 . Request ( url )
 i11iiiiI1i . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'dTM0ODczZWpyZGU4dTkyM2pxdzlkaXUy' ) )
 iIIii = urllib2 . urlopen ( i11iiiiI1i )
 i11I1IIiiIi = iIIii . read ( )
 iIIii . close ( )
 i11I1IIiiIi = i11I1IIiiIi . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 if '{' in i11I1IIiiIi :
  eV = i11I1IIiiIi [ : : - 1 ]
  eV = eV . replace ( '}' , '' ) . replace ( '{' , '' ) . replace ( ',' , '' ) . replace ( ']' , '' ) . replace ( '[' , '' )
  eV = eV + '=='
  i11I1IIiiIi = eV . decode ( 'base64' )
 if url <> IiI : i11I1IIiiIi = i11I1IIiiIi . replace ( '\n' , '' ) . replace ( '\r' , '' )
 print i11I1IIiiIi
 return i11I1IIiiIi
 if 18 - 18: IiiIII111ii . VevVVe
def VeeveeveeeeevVev ( url ) :
 i11iiiiI1i = urllib2 . Request ( url )
 i11iiiiI1i . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'dTM0ODczZWpyZGU4dTkyM2pxdzlkaXUy' ) )
 iIIii = urllib2 . urlopen ( i11iiiiI1i )
 i11I1IIiiIi = iIIii . read ( )
 iIIii . close ( )
 return i11I1IIiiIi
 if 40 - 40: Ii11111i - VeeevVVeveVV - i1iIIi1
def VVevVevevev ( url ) :
 i11iiiiI1i = urllib2 . Request ( url )
 i11iiiiI1i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 iIIii = urllib2 . urlopen ( i11iiiiI1i )
 i11I1IIiiIi = iIIii . read ( )
 iIIii . close ( )
 i11I1IIiiIi = i11I1IIiiIi . replace ( '\n' , '' ) . replace ( '\r' , '' )
 return i11I1IIiiIi
 if 37 - 37: Veveevev / Veeve / Ii11111i
 if 76 - 76: VevVVe . VevevVevVevVev - VVVevV - IiiIII111ii * VVeevevev
def VevVeevevV ( ) :
 VVeeveeveveveV = [ ]
 eVeveeveveVVeeVev = sys . argv [ 2 ]
 if len ( eVeveeveveVVeeVev ) >= 2 :
  VVVeveVVee = sys . argv [ 2 ]
  VVVeVevevev = VVVeveVVee . replace ( '?' , '' )
  if ( VVVeveVVee [ len ( VVVeveVVee ) - 1 ] == '/' ) :
   VVVeveVVee = VVVeveVVee [ 0 : len ( VVVeveVVee ) - 2 ]
  eVVVV = VVVeVevevev . split ( '&' )
  VVeeveeveveveV = { }
  for iIiIIIi in range ( len ( eVVVV ) ) :
   IiIi1ii111i1 = { }
   IiIi1ii111i1 = eVVVV [ iIiIIIi ] . split ( '=' )
   if ( len ( IiIi1ii111i1 ) ) == 2 :
    VVeeveeveveveV [ IiIi1ii111i1 [ 0 ] ] = IiIi1ii111i1 [ 1 ]
 return VVeeveeveveveV
 if 31 - 31: eVVVeeveevV + Ii11111i
def eevevVeveveVevev ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 87 - 87: VevevVevVevVev
def i1 ( string ) :
 IIIii = re . compile ( '(\[.+?\])' ) . findall ( string )
 for VevevVeeVeeveve in IIIii : string = string . replace ( VevevVeeVeeveve , '' )
 return string
 if 20 - 20: Ii * IiIi1Iii1I1 + Veeve % eeveee % I1ii
def Ii1i1i1i1I1Ii ( string ) :
 string = string . split ( ' ' )
 iIi1II = ''
 for I1iIiI11I1 in string :
  i1eVVeeeveevVVVV = '[B][COLOR yellow]' + I1iIiI11I1 [ 0 ] . upper ( ) + '[/COLOR][COLOR white]' + I1iIiI11I1 [ 1 : ] + '[/COLOR][/B] '
  iIi1II = iIi1II + i1eVVeeeveevVVVV
 return iIi1II
 if 26 - 26: IiiIII111ii % iiI1i1 + eeveee
def i1Veevev ( name , url , mode , iconimage , itemcount , metatype , isFolder = False , description = '' ) :
 if isFolder == True : VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 else : VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 if VVVeev == 'true' :
  VVVeee = name
  name = i1 ( name )
  VeeveveeevevevevVV = ""
  VeveVVeevVe = ""
  eevevevVevevev = [ ]
  ii1 = eval ( base64 . b64decode ( 'bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ==' ) )
  IIi = { }
  if metatype == 'movie' :
   eeeeeVeeeveee = name . partition ( '(' )
   if len ( eeeeeVeeeveee ) > 0 :
    VeeveveeevevevevVV = eeeeeVeeeveee [ 0 ]
    VeveVVeevVe = eeeeeVeeeveee [ 2 ] . partition ( ')' )
   if len ( VeveVVeevVe ) > 0 :
    VeveVVeevVe = VeveVVeevVe [ 0 ]
   IIi = ii1 . get_meta ( 'movie' , name = VeeveveeevevevevVV , year = VeveVVeevVe )
   if not IIi [ 'trailer' ] == '' : eevevevVevevev . append ( ( Ii1i1i1i1I1Ii ( 'Play Trailer' ) , 'XBMC.RunPlugin(%s)' % VeevVee . build_plugin_url ( { 'mode' : 11 , 'url' : IIi [ 'trailer' ] } ) ) )
  elif metatype == 'tvep' :
   iI1iII1 = VevVevVVevVevVev . getSetting ( 'tv' )
   if '<>' in url :
    print url
    eeevevVeveveV = url . split ( '<>' ) [ 0 ]
    eeveveVVeve = url . split ( '<>' ) [ 1 ]
    VVVevevV = url . split ( '<>' ) [ 2 ]
    VVeVVeveeeveeV = url . split ( '<>' ) [ 3 ]
    VeveevVevevVeeveev = url . split ( '<>' ) [ 4 ]
    VevevVeveVVevevVevev = url . split ( '<>' ) [ 5 ]
    IIi = ii1 . get_episode_meta ( eeveveVVeve , imdb_id = eeevevVeveveV , season = VVVevevV , episode = VVeVVeveeeveeV , air_date = '' , episode_title = '' , overlay = '' )
   else :
    eVeVeveeveee = re . compile ( 'Season (.+?) Episode (.+?)\)' ) . findall ( name )
    for eVeveevVevVeeeve , i1Ii11II in eVeVeveeveee :
     IIi = ii1 . get_episode_meta ( iI1iII1 , imdb_id = '' , season = eVeveevVevVeeeve , episode = i1Ii11II , air_date = '' , episode_title = '' , overlay = '' )
  try :
   if IIi [ 'cover_url' ] == '' : iconimage = iconimage
   else : iconimage = IIi [ 'cover_url' ]
  except : pass
  iI1i11iII111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( eeeevVV ) + "&iconimage=" + urllib . quote_plus ( iconimage )
  Iii1IIII11I = True
  eVVevVeveveVevVee = xbmcgui . ListItem ( VVVeee , iconImage = iconimage , thumbnailImage = iconimage )
  eVVevVeveveVevVee . setInfo ( type = "Video" , infoLabels = IIi )
  eVVevVeveveVevVee . setProperty ( "IsPlayable" , "true" )
  eVVevVeveveVevVee . addContextMenuItems ( eevevevVevevev , replaceItems = False )
  if not IIi . get ( 'backdrop_url' , '' ) == '' : eVVevVeveveVevVee . setProperty ( 'fanart_image' , IIi [ 'backdrop_url' ] )
  else : eVVevVeveveVevVee . setProperty ( 'fanart_image' , eeeevVV )
  IieVeveVVVevVee = VevVevVVevVevVev . getSetting ( 'favlist' )
  i1i1I = [ ]
  i1i1I . append ( ( Ii1i1i1i1I1Ii ( 'Stream Information' ) , 'XBMC.Action(Info)' ) )
  if IieVeveVVVevVee == 'yes' : i1i1I . append ( ( '[COLOR cyan]Remove From Keep Safe? [/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  else : i1i1I . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  eVVevVeveveVevVee . addContextMenuItems ( i1i1I , replaceItems = False )
  Iii1IIII11I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1i11iII111 , listitem = eVVevVeveveVevVee , isFolder = isFolder , totalItems = itemcount )
  return Iii1IIII11I
 else :
  if isFolder :
   i1I111I ( name , url , mode , iconimage , eeeevVV , description = '' )
  else :
   eeevVVe ( name , url , mode , iconimage , eeeevVV , description = '' )
   if 25 - 25: iiI1i1 + VVVevV + IiiIII111ii / Veeve / VVeVeeevevee
def i1I111I ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 iI1i11iII111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 Iii1IIII11I = True
 eVVevVeveveVevVee = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eVVevVeveveVevVee . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 eVVevVeveveVevVee . setProperty ( 'fanart_image' , fanart )
 if 'youtube.com/channel/' in url :
  iI1i11iII111 = 'plugin://plugin.video.youtube/channel/' + description + '/'
 if 'youtube.com/user/' in url :
  iI1i11iII111 = 'plugin://plugin.video.youtube/user/' + description + '/'
 if 'youtube.com/playlist?' in url :
  iI1i11iII111 = 'plugin://plugin.video.youtube/playlist/' + description + '/'
 if 'plugin://' in url :
  iI1i11iII111 = url
 i1i1I = [ ]
 IieVeveVVVevVee = VevVevVVevVevVev . getSetting ( 'favlist' )
 if IieVeveVVVevVee == 'yes' : i1i1I . append ( ( '[COLOR cyan]Remove From Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : i1i1I . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 eVVevVeveveVevVee . addContextMenuItems ( i1i1I , replaceItems = False )
 Iii1IIII11I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1i11iII111 , listitem = eVVevVeveveVevVee , isFolder = True )
 return Iii1IIII11I
 if 60 - 60: VevevVevVevVev * IiIi1Iii1I1 + II1Iiii1111i
def iII ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 iI1i11iII111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 Iii1IIII11I = True
 eVVevVeveveVevVee = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eVVevVeveveVevVee . setProperty ( 'fanart_image' , fanart )
 i1i1I = [ ]
 IieVeveVVVevVee = VevVevVVevVevVev . getSetting ( 'favlist' )
 if IieVeveVVVevVee == 'yes' : i1i1I . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : i1i1I . append ( ( '[COLOR cyan]Add to Keeo Safe[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 eVVevVeveveVevVee . addContextMenuItems ( i1i1I , replaceItems = False )
 Iii1IIII11I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1i11iII111 , listitem = eVVevVeveveVevVee , isFolder = False )
 return Iii1IIII11I
 if 19 - 19: VVeevevev * VVeVeeevevee / VVeVeeevevee . VeeevVVeveVV - eVVVeeveevV + i11iIiiIii
def eeevVVe ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 iI1i11iII111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 Iii1IIII11I = True
 eVVevVeveveVevVee = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eVVevVeveveVevVee . setProperty ( 'fanart_image' , fanart )
 eVVevVeveveVevVee . setProperty ( "IsPlayable" , "true" )
 i1i1I = [ ]
 IieVeveVVVevVee = VevVevVVevVevVev . getSetting ( 'favlist' )
 if IieVeveVVVevVee == 'yes' : i1i1I . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : i1i1I . append ( ( '[COLOR cyan]Add to Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 eVVevVeveveVevVee . addContextMenuItems ( i1i1I , replaceItems = False )
 Iii1IIII11I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1i11iII111 , listitem = eVVevVeveveVevVee , isFolder = False )
 return Iii1IIII11I
II = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvRXZvbHZlTWFpbk1lbnUueG1s' )
def iii11iII ( url , name ) :
 eeevVVeevV = VeeveeveeeeevVev ( url )
 if len ( eeevVVeevV ) > 1 :
  Ii1iI = eeVe
  IIieVeVeveveeevV = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( IIieVeVeveveeevV ) :
   file ( IIieVeVeveveeevV , 'w' ) . close ( )
  Ii1IiII = open ( IIieVeVeveveeevV )
  I1i = Ii1IiII . read ( )
  if I1i == eeevVVeevV : pass
  else :
   Ii1i1iI ( '[B][COLOR yellow]PICASSO INFO[/COLOR][/B]' , eeevVVeevV )
   IiiiI = open ( IIieVeVeveveeevV , "w" )
   IiiiI . write ( eeevVVeevV )
   IiiiI . close ( )
   if 72 - 72: iiI1i1
def Ii1i1iI ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 iiIi = xbmcgui . Window ( id )
 eVIi111 = 50
 while ( eVIi111 > 0 ) :
  try :
   xbmc . sleep ( 10 )
   eVIi111 -= 1
   iiIi . getControl ( 1 ) . setLabel ( heading )
   iiIi . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 67 - 67: Ii11111i
def Veeeeeeeeve ( name ) :
 global Icon
 global Next
 global Previous
 global window
 global Quit
 global images
 IIieVeVeveveeevV = os . path . join ( os . path . join ( eeVe , '' ) , name + '.txt' )
 Ii1IiII = open ( IIieVeVeveveeevV )
 I1i = Ii1IiII . read ( )
 images = re . compile ( '<image>(.+?)</image>' ) . findall ( I1i )
 VevVevVVevVevVev . setSetting ( 'pos' , '0' )
 window = pyxbmct . AddonDialogWindow ( '' )
 eeevVeVVVeveev = '/resources/art'
 iiI11I1i1i1iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeevVeVVVeveev , 'next_focus.png' ) )
 VeVVeeveveveev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeevVeVVVeveev , 'next1.png' ) )
 iiI1II11II1i = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeevVeVVVeveev , 'previous_focus.png' ) )
 eevVevVev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeevVeVVVeveev , 'previous.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeevVeVVVeveev , 'close_focus.png' ) )
 eeeveeVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeevVeVVVeveev , 'close.png' ) )
 iI1IiIIiIIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + eeevVeVVVeveev , 'main-bg1.png' ) )
 window . setGeometry ( 1300 , 720 , 100 , 50 )
 IiIi11Iii = pyxbmct . Image ( iI1IiIIiIIi )
 window . placeControl ( IiIi11Iii , - 10 , - 10 , 130 , 70 )
 i1Iii11I1i = '0xFF000000'
 Previous = pyxbmct . Button ( '' , focusTexture = iiI1II11II1i , noFocusTexture = eevVevVev , textColor = i1Iii11I1i , focusedColor = i1Iii11I1i )
 Next = pyxbmct . Button ( '' , focusTexture = iiI11I1i1i1iI , noFocusTexture = VeVVeeveveveev , textColor = i1Iii11I1i , focusedColor = i1Iii11I1i )
 Quit = pyxbmct . Button ( '' , focusTexture = I11 , noFocusTexture = eeeveeVV , textColor = i1Iii11I1i , focusedColor = i1Iii11I1i )
 Icon = pyxbmct . Image ( images [ 0 ] , aspectRatio = 2 )
 window . placeControl ( Previous , 102 , 1 , 10 , 10 )
 window . placeControl ( Next , 102 , 40 , 10 , 10 )
 window . placeControl ( Quit , 102 , 21 , 10 , 10 )
 window . placeControl ( Icon , 0 , 0 , 100 , 50 )
 Previous . controlRight ( Next )
 Previous . controlUp ( Quit )
 window . connect ( Previous , III1i1iI1 )
 window . connect ( Next , eeveeeeveve )
 Previous . setVisible ( False )
 window . setFocus ( Quit )
 Previous . controlRight ( Quit )
 Quit . controlLeft ( Previous )
 Quit . controlRight ( Next )
 Next . controlLeft ( Quit )
 window . connect ( Quit , window . close )
 window . doModal ( )
 del window
 if 62 - 62: II1Iiii1111i * Veveevev
def eeveeeeveve ( ) :
 VVev = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 VVVeveVVeevevV = int ( VVev ) + 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( VVVeveVVeevevV ) )
 VVeveIII111i11IiI = len ( images )
 Icon . setImage ( images [ int ( VVVeveVVeevevV ) ] )
 Previous . setVisible ( True )
 if int ( VVVeveVVeevevV ) == int ( VVeveIII111i11IiI ) - 1 :
  Next . setVisible ( False )
  if 71 - 71: VVeVeeevevee / VVeVeeevevee * I1ii * I1ii / Veeve
def III1i1iI1 ( ) :
 VVev = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 II1I1iiIII1I1 = int ( VVev ) - 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( II1I1iiIII1I1 ) )
 Icon . setImage ( images [ int ( II1I1iiIII1I1 ) ] )
 Next . setVisible ( True )
 if int ( II1I1iiIII1I1 ) == 0 :
  Previous . setVisible ( False )
  if 85 - 85: IiiIII111ii * eeveee
def ii1iii11i1 ( url , fanart ) :
 VevVevVVevVevVev . setSetting ( 'favlist' , 'yes' )
 I11VeeveveVevV = None
 file = open ( Ve , 'r' )
 I11VeeveveVevV = file . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 iI = re . compile ( "<item>(.+?)</item>" , re . DOTALL ) . findall ( I11VeeveveVevV )
 for iI11iiiI1II in iI :
  eeveV ( Ii11iii11I , url , Veveveeeeeevev , fanart , iI11iiiI1II )
 VevVevVVevVevVev . setSetting ( 'favlist' , 'no' )
 if 96 - 96: VVVevV / Veeve . i11IiIiiIIIII - IiiIII111ii * VVeVeeevevee * I1ii
def VeveveeeveeV ( name , url , iconimage , fanart ) :
 iiIii1ii = VevVevVVevVevVev . getSetting ( 'favtype' )
 url = url . replace ( ' ' , '%20' )
 iconimage = iconimage . replace ( ' ' , '%20' )
 if '<>' in url :
  eeevevVeveveV = url . split ( '<>' ) [ 0 ]
  VVVevevV = url . split ( '<>' ) [ 1 ]
  VVeVVeveeeveeV = url . split ( '<>' ) [ 2 ]
  VeveevVevevVeeveev = url . split ( '<>' ) [ 3 ]
  VevevVeveVVevevVevev = url . split ( '<>' ) [ 4 ]
  eV = '<FAV><item>\n<title>' + name + '</title>\n<meta>tvep</meta>\n<nan>tvshow</nan>\n<showyear>' + VeveevVevevVeeveev + '</showyear>\n<imdb>' + eeevevVeveveV + '</imdb>\n<season>' + VVVevevV + '</season>\n<episode>' + VVeVVeveeeveeV + '</episode>\n<episodeyear>' + VevevVeveVVevevVevev + '</episodeyear>\n<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 elif len ( url ) == 9 :
  eV = '<FAV><item>\n<title>' + name + '</title>\n<meta>movie</meta>\n<nan>movie</nan>\n<imdb>' + url + '</imdb>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 else :
  eV = '<FAV><item>\n<title>' + name + '</title>\n<' + iiIii1ii + '>' + url + '</' + iiIii1ii + '>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 IiII = open ( Ve , 'a' )
 IiII . write ( eV )
 IiII . close ( )
 if 33 - 33: IiIi1Iii1I1
def VVVeveee ( name , url , iconimage ) :
 print name
 I11VeeveveVevV = None
 file = open ( Ve , 'r' )
 I11VeeveveVevV = file . read ( )
 IIiiii = ''
 iI = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( I11VeeveveVevV )
 for VeveeeeevVeevev in iI :
  eV = '\n<FAV><item>\n' + VeveeeeevVeevev + '</item>\n'
  if name in VeveeeeevVeevev :
   print 'xxxxxxxxxxxxxxxxx'
   eV = eV . replace ( 'item' , ' ' )
  IIiiii = IIiiii + eV
 file = open ( Ve , 'w' )
 file . truncate ( )
 file . write ( IIiiii )
 file . close ( )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 37 - 37: eeveee % VevevVevVevVev
def VevevevVVeevevee ( url ) :
 try :
  eVevee = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  file = open ( IIi1IiiiI1Ii , 'r' )
  VevII11i11II = file . read ( )
  if eVevee in VevII11i11II : return '[COLOR cyan] (RD)[/COLOR]'
  else : return ''
 except : return ''
 if 29 - 29: II1Iiii1111i % VVeevevev % i1iIIi1 . eeveee / VeeevVVeveVV * VevevVevVevVev
def eev ( ) :
 xbmcaddon . Addon ( ) . openSettings ( )
 if 78 - 78: iiI1i1 + VVeVeeevevee - i11IiIiiIIIII * IiIi1Iii1I1 - VeeevVVeveVV % Veveevev
def i1VeVV ( ) :
 xbmcaddon . Addon ( 'script.module.nanscrapers' ) . openSettings ( )
 if 44 - 44: eVVVeeveevV
def VevVeveeveeve ( ) :
 xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
 if 9 - 9: II1Iiii1111i + Veveevev - iiI1i1 - i11IiIiiIIIII + eeveee
def eevevevVevVVee ( ) :
 xbmcaddon . Addon ( 'script.module.metahandler' ) . openSettings ( )
 if 60 - 60: VevVVe * IiIi1Iii1I1 % VVeevevev + I1ii
def eVee ( link ) :
 try :
  eevee = re . compile ( '<layouttype>(.+?)</layouttype>' ) . findall ( link ) [ 0 ]
  if eevee == 'thumbnail' : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 except : pass
 if 80 - 80: IiIi1Iii1I1 * Veveevev * Veeve - Ii11111i . Veveevev % VevVVe
 if 13 - 13: I1ii . VevVVe * I1ii + VevVVe
VVVeveVVee = VevVeevevV ( ) ; VeI1Ii11I1Ii1i = None ; Ii11iii11I = None ; VeVVeve = None ; VeVeee = None ; eVeevevVeevevV = None ; eeevevVVeVeVevev = None
try : VeVeee = urllib . unquote_plus ( VVVeveVVee [ "site" ] )
except : pass
try : VeI1Ii11I1Ii1i = urllib . unquote_plus ( VVVeveVVee [ "url" ] )
except : pass
try : Ii11iii11I = urllib . unquote_plus ( VVVeveVVee [ "name" ] )
except : pass
try : VeVVeve = int ( VVVeveVVee [ "mode" ] )
except : pass
try : eVeevevVeevevV = urllib . unquote_plus ( VVVeveVVee [ "iconimage" ] )
except : pass
try : eeeevVV = urllib . unquote_plus ( VVVeveVVee [ "fanart" ] )
except : pass
try : eeevevVVeVeVevev = str ( VVVeveVVee [ "description" ] )
except : pass
if 15 - 15: i1iIIi1 / Ii11111i . eeveee . i11iIiiIii
if VeVVeve == None or VeI1Ii11I1Ii1i == None or len ( VeI1Ii11I1Ii1i ) < 1 : ee ( )
elif VeVVeve == 1 : VeVVVeveveVVev ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 2 : eeeeveveveeVevevevev ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeevevVVeVeVevev )
elif VeVVeve == 3 : Veeeev ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV )
elif VeVVeve == 4 : VVee ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV )
elif VeVVeve == 5 : IIiii11i ( )
elif VeVVeve == 6 : iII111i ( VeI1Ii11I1Ii1i , eVeevevVeevevV )
elif VeVVeve == 7 : eeevevVeveveVeveveve ( VeI1Ii11I1Ii1i )
elif VeVVeve == 8 : Veeeeeeeeve ( Ii11iii11I )
elif VeVVeve == 9 : VVVeVeV ( Ii11iii11I , VeI1Ii11I1Ii1i )
elif VeVVeve == 10 : eVeVeveveeevV ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 11 : iI1iIIIi1i ( VeI1Ii11I1Ii1i )
elif VeVVeve == 12 : VevVeveeveeve ( )
elif VeVVeve == 13 : eevevevVevVVee ( )
elif VeVVeve == 15 : SCRAPEMOVIE ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV )
elif VeVVeve == 16 : eVeeeeevevevVeevev ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV )
elif VeVVeve == 17 : I11i1II ( Ii11iii11I , VeI1Ii11I1Ii1i )
elif VeVVeve == 18 : eVVeeevevVeveve ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 19 : eevevevVeve ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
if 59 - 59: IiIi1Iii1I1 - eeveee - VevevVevVevVev
elif VeVVeve == 20 : VeveveeeveeV ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 21 : VVVeveee ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV )
elif VeVVeve == 22 : ii1iii11i1 ( VeI1Ii11I1Ii1i , eeeevVV )
elif VeVVeve == 23 : DOIPLAYER ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 24 : VeevVev ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 25 : i1VeVV ( )
if 48 - 48: Ii + VVeVeeevevee % Veveevev / II1Iiii1111i - eeveee
elif VeVVeve == 26 : VevVeveveevVVVev ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 27 : i1iiI11I ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 28 : VVeV ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 29 : iIiIi11iI ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 30 : I11iII ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 31 : VeVevevevVevVe ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 32 : eeveveveveV ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 33 : eevevVeeveeeeee ( VeI1Ii11I1Ii1i )
elif VeVVeve == 34 : I1III1111iIi ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 35 : VeeVeeveeevVeveevevV ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
if 67 - 67: I1ii % eeveee . VeeevVVeveVV + eVVVeeveevV * VVeVeeevevee * Veveevev
elif VeVVeve == 36 : eevVeveve ( )
elif VeVVeve == 37 : VVevVeeeev ( VeI1Ii11I1Ii1i )
elif VeVVeve == 38 : eVevevVVeVevev ( VeI1Ii11I1Ii1i )
elif VeVVeve == 39 : VeVV ( VeI1Ii11I1Ii1i )
elif VeVVeve == 40 : I1iI1iIi111i ( )
elif VeVVeve == 41 : VeveeeveveevV ( VeI1Ii11I1Ii1i )
elif VeVVeve == 42 : VVVVVeeev ( VeI1Ii11I1Ii1i )
if 36 - 36: Ii11111i + II1Iiii1111i
elif VeVVeve == 43 : eVVeeevevevevVeveev ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 44 : eeeveevevevev ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 45 : IiIIII1i11I ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 46 : VVe ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
if 5 - 5: II1Iiii1111i * Veveevev
elif VeVVeve == 47 : DODOCLOGMENU ( )
elif VeVVeve == 48 : GET_DOCCONTENT ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , II1 )
elif VeVVeve == 49 : DO_DOCCONTENT ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , II1 )
elif VeVVeve == 50 : RESOLVE2 ( VeI1Ii11I1Ii1i )
elif VeVVeve == 51 : eevVeVeeveveeve ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV , eeeevVV )
elif VeVVeve == 52 : I11iiii ( Ii11iii11I , VeI1Ii11I1Ii1i , eVeevevVeevevV )
elif VeVVeve == 53 : eev ( )
if 46 - 46: VevevVevVevVev
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
